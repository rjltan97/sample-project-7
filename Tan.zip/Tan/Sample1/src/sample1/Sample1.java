
package sample1;
import java.util.*;
public class Sample1 {
   
     
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    int num1, num2, sum, diff, prod, quot;
    System.out.println("Enter the first number: ");
    num1 = input.nextInt();
    System.out.println("Enter the second number: ");
    num2 = input.nextInt();
    sum = num1 + num2;
    diff = num1 - num2;
    prod = num1 * num2;
    quot = num1/num2;
    System.out.println("The sum of the numbers is: "+ sum);
    System.out.println("The diff of the numbers is: "+ diff);
    System.out.println("The prod of the numbers is: "+ prod);
    System.out.println("The quot of the numbers is: "+ quot);
    }
}
