
package order;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class OrderUI extends javax.swing.JFrame {
int price1 ,price2, price3;
String color, size, food;

    public OrderUI() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        Panel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Burgers = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        YES = new javax.swing.JButton();
        NO = new javax.swing.JButton();
        SMA = new javax.swing.JRadioButton();
        MED = new javax.swing.JRadioButton();
        LAR = new javax.swing.JRadioButton();
        Total = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Panel.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 51, 51));

        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel1.setText("WHAT KIND OF BURGER WOULD YOU LIKE?");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        Burgers.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Regular Yum", "Regular Yum w/ Cheese", "Double Yum", "Champ" }));

        jPanel2.setBackground(new java.awt.Color(255, 102, 102));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel2.setText("WOULD YOU LIKE TO ORDER FRIES?");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(255, 51, 51));

        jLabel3.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel3.setText("WHAT KIND OF BURGER WOULD YOU LIKE?");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        YES.setText("YES");
        YES.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                YESActionPerformed(evt);
            }
        });

        NO.setText("NO");
        NO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NOActionPerformed(evt);
            }
        });

        buttonGroup1.add(SMA);
        SMA.setText("Small");
        SMA.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                SMAItemStateChanged(evt);
            }
        });

        buttonGroup1.add(MED);
        MED.setText("Medium");
        MED.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                MEDItemStateChanged(evt);
            }
        });

        buttonGroup1.add(LAR);
        LAR.setText("Large");
        LAR.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                LARItemStateChanged(evt);
            }
        });

        Total.setText("TOTAL BILL");
        Total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelLayout = new javax.swing.GroupLayout(Panel);
        Panel.setLayout(PanelLayout);
        PanelLayout.setHorizontalGroup(
            PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelLayout.createSequentialGroup()
                .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelLayout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(Burgers, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelLayout.createSequentialGroup()
                        .addGap(106, 106, 106)
                        .addComponent(YES)
                        .addGap(88, 88, 88)
                        .addComponent(NO))
                    .addGroup(PanelLayout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(30, Short.MAX_VALUE))
            .addGroup(PanelLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(SMA)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addComponent(MED)
                .addGap(65, 65, 65)
                .addComponent(LAR)
                .addGap(79, 79, 79))
        );
        PanelLayout.setVerticalGroup(
            PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Burgers, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NO)
                    .addComponent(YES))
                .addGap(19, 19, 19)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SMA)
                    .addComponent(LAR)
                    .addComponent(MED))
                .addGap(40, 40, 40)
                .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SMAItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_SMAItemStateChanged
        // TODO add your handling code here:
        if(evt.getSource()==SMA){
            if (evt.getStateChange()== ItemEvent.SELECTED){
                price1 = +10;
                size = "Small";
            }
        }
    }//GEN-LAST:event_SMAItemStateChanged

    private void MEDItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_MEDItemStateChanged
        // TODO add your handling code here:
        if(evt.getSource()==MED){
            if (evt.getStateChange()== ItemEvent.SELECTED){
                price1 = +20;
                size = "Medium";
            }
        }
    }//GEN-LAST:event_MEDItemStateChanged

    private void LARItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_LARItemStateChanged
        // TODO add your handling code here:
        if(evt.getSource()==LAR){
            if (evt.getStateChange()== ItemEvent.SELECTED){
                price1 = +30;
                size = "Large";
            }
        }
    }//GEN-LAST:event_LARItemStateChanged

    private void TotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalActionPerformed
        // TODO add your handling code here:
        int total = price1+price2+price3;
        char text, option;
        
        
        Object burg = Burgers.getSelectedItem();
        
        String bb = (String) burg;
        
         if(bb.equals("Regular Yum")){
            
            JOptionPane.showMessageDialog(null, "Burger: " + bb + "\nFries: " + YES.getText() + "\nSize: " + size + "\nTotal Price: " + total, "Alert", JOptionPane.INFORMATION_MESSAGE);      
            }
         else if(bb.equals("Regular Yum w/ Cheese")){
           
            JOptionPane.showMessageDialog(null, "Burger: " + bb + "\nFries: " + YES.getText() + "\nSize: " + size + "\nTotal Price: " + total, "Alert", JOptionPane.INFORMATION_MESSAGE);        
            }
         else if(bb.equals("Double Yum")){
             
            JOptionPane.showMessageDialog(null, "Burger: " + bb + "\nFries: " + YES.getText() + "\nSize: " + size + "\nTotal Price: " + total, "Alert", JOptionPane.INFORMATION_MESSAGE);      
            }
         else if(bb.equals("Champ")){ 
           
            JOptionPane.showMessageDialog(null, "Burger: " + bb + "\nFries: " + YES.getText() + "\nSize: " + size + "\nTotal Price: " + total, "Alert", JOptionPane.INFORMATION_MESSAGE);     
            }
    }//GEN-LAST:event_TotalActionPerformed

    private void YESActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_YESActionPerformed
        // TODO add your handling code here:
        YES.setText("Yes");
        price2 = +10;
        
    }//GEN-LAST:event_YESActionPerformed

    private void NOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NOActionPerformed
        // TODO add your handling code here:
        NO.setText("No");
        price2 = -10;
        
    }//GEN-LAST:event_NOActionPerformed


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new OrderUI().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox Burgers;
    private javax.swing.JRadioButton LAR;
    private javax.swing.JRadioButton MED;
    private javax.swing.JButton NO;
    private javax.swing.JPanel Panel;
    private javax.swing.JRadioButton SMA;
    private javax.swing.JButton Total;
    private javax.swing.JButton YES;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
