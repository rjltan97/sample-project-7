
package drawimage;
import javax.swing.*;
import java.awt.*;
public class DrawImage2 extends JApplet {
    int choice;
    Image img, img2, img3;
    MediaTracker tr, tr2, tr3;
    
    
    public void init(){
        String input;
        
        input = JOptionPane.showInputDialog(
                "Enter 1 to Display Image 1\n" +
                "           2 to Display Image 2\n" +
                "           3 to Display Image 3\n");
        choice = Integer.parseInt(input);
    }
    
    public void paint(Graphics g){
        super.paint(g);

        switch(choice){
            case 1:
           tr=new MediaTracker(this);
           img=getImage(getCodeBase(),"1.jpg");
           tr.addImage(img,0);
           g.drawImage(img,0,0,this);
                break;
            case 2:
           tr=new MediaTracker(this);
           img=getImage(getCodeBase(),"2.jpg");
           tr.addImage(img,0);
           g.drawImage(img,0,0,this);
                break;
            case 3:
           tr=new MediaTracker(this);
           img=getImage(getCodeBase(),"3.jpg");
           tr.addImage(img,0);
           g.drawImage(img,0,0,this);   
                break;
            default:
                
        }
        }
    }
