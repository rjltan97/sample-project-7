
package drawimage;

import javax.swing.*;
import java.awt.*;

public class DrawImage extends JApplet {

   Image img;
   MediaTracker tr;
           
       public void paint(Graphics g){
           tr=new MediaTracker(this);
           img=getImage(getCodeBase(),"h.jpg");
           tr.addImage(img,0);
           g.drawImage(img,0,0,this);
       }
}
