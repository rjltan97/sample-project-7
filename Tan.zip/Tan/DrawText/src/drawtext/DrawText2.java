
package drawtext;
import javax.swing.JApplet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.*;


public class DrawText2 extends JApplet {
    Font header = new Font("Times New Roman", 3,24);
    Font subheader = new Font("Helvetica", Font.BOLD,24);
    Font body = new Font("Courier", Font.ITALIC,16);
    Font details = new Font("Courier", 0,12);
    Color red = new Color(255,0,0);
    Color green = new Color(0,255,0);
    Color blue = new Color(0,0,255);
    
    public void init(){
        setBackground(Color.orange);
        setForeground(Color.black);
    }
    
    public void paint(Graphics e){
    e.setColor(red);
    e.setFont(header);
    e.drawString("MY PROFILE", 250, 20);
    e.setColor(blue);
    e.setFont(subheader);
    e.drawString("Name: Robin Joshua L. Tan", 10, 60);
    e.setColor(blue);
    e.setFont(subheader);
    e.drawString("Year/Course: 2ND YEAR BSIT", 10, 120);
    e.setColor(green);
    e.setFont(body);
    e.drawString("College: CCIS", 10, 180);
    e.setColor(green);
    e.setFont(body);
    e.drawString("E-Mail: haruhikomiyazono@gmail.com", 10, 240);
    e.setColor(red);
    e.setFont(details);
    e.drawString("Contact No: 123-3456", 10, 300);
    e.setColor(red);
    e.setFont(details);
    e.drawString("Home Address: Quezon City, Philippines", 10, 360);
    }
}
