/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package drawtext;

/**
 *
 * @author student
 */
import javax.swing.JApplet;
import java.awt.*;

public class DrawText3 extends JApplet {
    Font header = new Font("Times New Roman", 3,24);
    Font subheader = new Font("Helvetica", Font.BOLD,24);
    Font body = new Font("Courier", Font.ITALIC,16);
    Font details = new Font("Courier", 0,12);
    Color red = new Color(255,0,0);
    Color green = new Color(0,255,0);
    Color blue = new Color(0,0,255);
    
    
    public void paint(Graphics r){
        r.setColor(red);
        r.setFont(header);
        r.drawString("Times New Roman, Bold and Italic, point 24", 10, 30);
        r.setColor(green);
        r.setFont(subheader);
        r.drawString("Helvetica, Bold, point 24",10,60);
        r.setColor(blue);
        r.setFont(body);
        r.drawString("Courier, Italic, point 16", 10, 90);
        r.setFont(details);
        r.drawString("Courier, Plain, point 12", 10, 120);
    }
}
