/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package drawtext;

/**
 *
 * @author student
 */
import javax.swing.JApplet;
import java.awt.Color;
import java.awt.Graphics;
public class DrawText extends JApplet {

    /**
     * @param args the command line arguments
     */
public void init(){
    setBackground(Color.yellow);
    setForeground(Color.red);
}

public void paint(Graphics g){
    g.drawString("Top Left", 0, 10);
    g.drawString("Top Right", 440, 10);
    g.drawString("Bottom Left", 0, 200);
    g.drawString("Bottom Right", 420, 200);
    g.drawString("Middle", 200, 100);
}
}
