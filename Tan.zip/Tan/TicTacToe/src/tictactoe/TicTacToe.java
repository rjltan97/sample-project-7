
package tictactoe;
import javax.swing.*;

public class TicTacToe {
    public static boolean playerTurn = true;
    public static boolean player1Won = false;
    public static boolean player2Won = false;
    
    //Instantiation
    public static TicTacUI board = new TicTacUI();

    public static void main(String[] args) {
        if(board.isVisible() == false ){
            board.setVisible(true);
        }
    }
    public static void checkforwin(){
        //COMBINATION FOR X
        //VERTICAL
        //1 4 7
        if (board.jButton1.getText().equals("X")){
            if(board.jButton4.getText().equals("X")){
                if(board.jButton7.getText().equals("X")){
                    player1Won = true;
                    player2Won = false;
                    
                    JOptionPane.showMessageDialog(null, "Player 1 won!");
                    endgame();
                }
            }
        }
       // 2 5 8
       if (board.jButton2.getText().equals("X")){
            if(board.jButton5.getText().equals("X")){
                if(board.jButton8.getText().equals("X")){
                    player1Won = true;
                    player2Won = false;
                    
                    JOptionPane.showMessageDialog(null, "Player 1 won!");
                    endgame();
                }
            }
        }
       // 3 6 9
       if (board.jButton3.getText().equals("X")){
            if(board.jButton6.getText().equals("X")){
                if(board.jButton9.getText().equals("X")){
                    player1Won = true;
                    player2Won = false;
                    
                    JOptionPane.showMessageDialog(null, "Player 1 won!");
                    endgame();
                }
            }
        }
       //HORIZONTAL
       // 1 2 3
       if (board.jButton1.getText().equals("X")){
            if(board.jButton2.getText().equals("X")){
                if(board.jButton3.getText().equals("X")){
                    player1Won = true;
                    player2Won = false;
                    
                    JOptionPane.showMessageDialog(null, "Player 1 won!");
                    endgame();
                }
            }
        }
       //4 5 6
       if (board.jButton4.getText().equals("X")){
            if(board.jButton5.getText().equals("X")){
                if(board.jButton6.getText().equals("X")){
                    player1Won = true;
                    player2Won = false;
                    
                    JOptionPane.showMessageDialog(null, "Player 1 won!");
                    endgame();
                }
            }
        }
       // 7 8 9
       if (board.jButton7.getText().equals("X")){
            if(board.jButton8.getText().equals("X")){
                if(board.jButton9.getText().equals("X")){
                    player1Won = true;
                    player2Won = false;
                    
                    JOptionPane.showMessageDialog(null, "Player 1 won!");
                    endgame();
                }
            }
        }
       
       //DIAGONAL
       //1 5 9
       if (board.jButton1.getText().equals("X")){
            if(board.jButton5.getText().equals("X")){
                if(board.jButton9.getText().equals("X")){
                    player1Won = true;
                    player2Won = false;
                    
                    JOptionPane.showMessageDialog(null, "Player 1 won!");
                    endgame();
                }
            }
        }
       // 3 5 7
       if (board.jButton3.getText().equals("X")){
            if(board.jButton5.getText().equals("X")){
                if(board.jButton7.getText().equals("X")){
                    player1Won = true;
                    player2Won = false;
                    
                    JOptionPane.showMessageDialog(null, "Player 1 won!");
                    endgame();
                }
            }
        }
       
       
       
       //PLAYER 2     
       //COMBINATION FOR X
        //VERTICAL
        //1 4 7
        if(board.jButton1.getText().equals("O")){
        if(board.jButton4.getText().equals("O")){
        if(board.jButton7.getText().equals("O")){
                 player1Won = false;
                 player2Won = true;
                    
                 JOptionPane.showMessageDialog(null, "Player 2 won!");
                 endgame();
                }
            }
        }
       // 2 5 8
       if(board.jButton2.getText().equals("O")){
       if(board.jButton5.getText().equals("O")){
       if(board.jButton8.getText().equals("O")){
                    player1Won = false;
                    player2Won = true;
                    
                    JOptionPane.showMessageDialog(null, "Player 2 won!");
                    endgame();
                }
            }
        }
       // 3 6 9
       if(board.jButton3.getText().equals("O")){
       if(board.jButton6.getText().equals("O")){
       if(board.jButton9.getText().equals("O")){
                    player1Won = false;
                    player2Won = true;
                    
                    JOptionPane.showMessageDialog(null, "Player 2 won!");
                    endgame();
                }
            }
        }
       //HORIZONTAL
       // 1 2 3
       if(board.jButton1.getText().equals("O")){
       if(board.jButton2.getText().equals("O")){
       if(board.jButton3.getText().equals("O")){
                    player1Won = false;
                    player2Won = true;
                    
                    JOptionPane.showMessageDialog(null, "Player 2 won!");
                    endgame();
                }
            }
        }
       //4 5 6
       if (board.jButton4.getText().equals("O")){
            if(board.jButton5.getText().equals("O")){
                if(board.jButton6.getText().equals("O")){
                    player1Won = false;
                    player2Won = true;
                    
                    JOptionPane.showMessageDialog(null, "Player 2 won!");
                    endgame();
                }
            }
        }
       // 7 8 9
       if (board.jButton7.getText().equals("O")){
            if(board.jButton8.getText().equals("O")){
                if(board.jButton9.getText().equals("O")){
                    player1Won = false;
                    player2Won = true;
                    
                    JOptionPane.showMessageDialog(null, "Player 2 won!");
                    endgame();
                }
            }
        }
       
       //DIAGONAL
       //1 5 9
       if (board.jButton1.getText().equals("O")){
            if(board.jButton5.getText().equals("O")){
                if(board.jButton9.getText().equals("O")){
                    player1Won = false;
                    player2Won = true;
                    
                    JOptionPane.showMessageDialog(null, "Player 2 won!");
                    endgame();
                }
            }
        }
       // 3 5 7
       if (board.jButton3.getText().equals("O")){
            if(board.jButton5.getText().equals("O")){
                if(board.jButton7.getText().equals("O")){
                    player1Won = false;
                    player2Won = true;
                   
                    JOptionPane.showMessageDialog(null, "Player 2 won!");
                    endgame();
                }
            }
        }
    }//END BRACE 
   
    public static void endgame(){
        board.jButton1.setEnabled(false);
        board.jButton2.setEnabled(false);
        board.jButton3.setEnabled(false);
        board.jButton4.setEnabled(false);
        board.jButton5.setEnabled(false);
        board.jButton6.setEnabled(false);
        board.jButton7.setEnabled(false);
        board.jButton8.setEnabled(false);
        board.jButton9.setEnabled(false);
        
    }
            
    
} //END CLASS
