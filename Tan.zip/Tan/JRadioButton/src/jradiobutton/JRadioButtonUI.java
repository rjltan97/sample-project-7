
package jradiobutton;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class JRadioButtonUI extends javax.swing.JFrame {
        ImageIcon cnt[]=
    {
        new ImageIcon("Sing.jpg"),
        new ImageIcon("Man.jpg"),
        new ImageIcon("Kor.jpg"),
        new ImageIcon("Jap.jpg")
    };
        
     ImageIcon default_img = new ImageIcon("Flag.jpg");

    public JRadioButtonUI() {
        initComponents();
        City.setIcon(default_img);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        PanelIMG = new javax.swing.JPanel();
        City = new javax.swing.JLabel();
        PanelBtn = new javax.swing.JPanel();
        Japan = new javax.swing.JRadioButton();
        Manila = new javax.swing.JRadioButton();
        Singapore = new javax.swing.JRadioButton();
        Korea = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Countries");

        PanelIMG.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout PanelIMGLayout = new javax.swing.GroupLayout(PanelIMG);
        PanelIMG.setLayout(PanelIMGLayout);
        PanelIMGLayout.setHorizontalGroup(
            PanelIMGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(City, javax.swing.GroupLayout.DEFAULT_SIZE, 384, Short.MAX_VALUE)
        );
        PanelIMGLayout.setVerticalGroup(
            PanelIMGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(City, javax.swing.GroupLayout.DEFAULT_SIZE, 262, Short.MAX_VALUE)
        );

        PanelBtn.setBackground(new java.awt.Color(0, 0, 0));

        Japan.setBackground(new java.awt.Color(51, 51, 51));
        buttonGroup1.add(Japan);
        Japan.setForeground(new java.awt.Color(255, 255, 102));
        Japan.setText("Land of the Rising Sun");
        Japan.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                JapanItemStateChanged(evt);
            }
        });

        Manila.setBackground(new java.awt.Color(51, 51, 51));
        buttonGroup1.add(Manila);
        Manila.setForeground(new java.awt.Color(255, 255, 102));
        Manila.setText("Pearl of the Orient");
        Manila.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ManilaItemStateChanged(evt);
            }
        });

        Singapore.setBackground(new java.awt.Color(51, 51, 51));
        buttonGroup1.add(Singapore);
        Singapore.setForeground(new java.awt.Color(255, 255, 102));
        Singapore.setText("The Lion City");
        Singapore.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                SingaporeItemStateChanged(evt);
            }
        });

        Korea.setBackground(new java.awt.Color(51, 51, 51));
        buttonGroup1.add(Korea);
        Korea.setForeground(new java.awt.Color(255, 255, 102));
        Korea.setText("Land of the Morning Calm");
        Korea.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                KoreaItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout PanelBtnLayout = new javax.swing.GroupLayout(PanelBtn);
        PanelBtn.setLayout(PanelBtnLayout);
        PanelBtnLayout.setHorizontalGroup(
            PanelBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelBtnLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(PanelBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Japan)
                    .addComponent(Korea)
                    .addComponent(Manila)
                    .addComponent(Singapore))
                .addContainerGap(78, Short.MAX_VALUE))
        );
        PanelBtnLayout.setVerticalGroup(
            PanelBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelBtnLayout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(Japan)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Korea)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Singapore)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Manila)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(PanelIMG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(PanelBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(74, 74, 74))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(PanelIMG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PanelBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JapanItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_JapanItemStateChanged
        if (evt.getSource() == Japan){
            if (evt.getStateChange() == ItemEvent.SELECTED){
                City.setIcon(cnt[3]);
            }
           }
    }//GEN-LAST:event_JapanItemStateChanged

    private void KoreaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_KoreaItemStateChanged
        if (evt.getSource() == Korea){
            if (evt.getStateChange() == ItemEvent.SELECTED){
                City.setIcon(cnt[2]);
            }
           }
    }//GEN-LAST:event_KoreaItemStateChanged

    private void SingaporeItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_SingaporeItemStateChanged
        if (evt.getSource() == Singapore){
            if (evt.getStateChange() == ItemEvent.SELECTED){
                City.setIcon(cnt[0]);
            }
           }
    }//GEN-LAST:event_SingaporeItemStateChanged

    private void ManilaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ManilaItemStateChanged
        if (evt.getSource() == Manila){
            if (evt.getStateChange() == ItemEvent.SELECTED){
                City.setIcon(cnt[1]);
            }
           }
    }//GEN-LAST:event_ManilaItemStateChanged


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new JRadioButtonUI().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel City;
    private javax.swing.JRadioButton Japan;
    private javax.swing.JRadioButton Korea;
    private javax.swing.JRadioButton Manila;
    private javax.swing.JPanel PanelBtn;
    private javax.swing.JPanel PanelIMG;
    private javax.swing.JRadioButton Singapore;
    private javax.swing.ButtonGroup buttonGroup1;
    // End of variables declaration//GEN-END:variables
}
