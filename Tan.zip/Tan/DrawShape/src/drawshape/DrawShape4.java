
package drawshape;

import java.awt.*;
import javax.swing.JApplet;

public class DrawShape4 extends JApplet {
    
    Font header = new Font("SansSerif", Font.BOLD, 24);
    String text;
    int delayLimit;
		
    @Override
    public void init() {
	text = "Robin Tan";
	delayLimit = 50000000;
    }
	
    @Override
    public void paint(Graphics g) {
	g.setFont(header);
	for(int y = 0; y < 200; y++) {
            //user-defined delay function
            for(int delay = 0; delay < delayLimit; delay++);
			
            g.setColor(new Color(255, 255, 255));	//white
            g.fillRect(0, y, 180, 30);
            g.setColor(new Color(0, 0, 0));	//black
            g.drawString(text, 0, y+20);
	}
    }
}

