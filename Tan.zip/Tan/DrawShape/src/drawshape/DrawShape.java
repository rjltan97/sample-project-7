
package drawshape;

import java.awt.*;
import javax.swing.JApplet;

public class DrawShape extends JApplet {
int x, y, z;
int flag = 1;
int r = (int)Math.random()*100;
int gr = (int)Math.random()*100;
int b = (int)Math.random()*100;

Color c = new Color(r,gr,b);
Color w = new Color(r,gr,b);
Color a = new Color(r,gr,b);

   public void paint(Graphics g){
       super.paint(g);
       
       //GRID
       for (x = 0; x<=10 ; x++) 
       {
       
           
       if(flag==1)
       {
           g.setColor(Color.red);
           flag = 2;
       } 
       
       else if (flag==2)
       
       {
           
           g.setColor(Color.blue);
           flag = 1;
       }
           
               
       g.drawLine(y,10,y,100);
       y+=10;   
       
       }
       y=10;
       //H
       for (x = 0; x<=10 ; x++) 
       {
       if(flag==1)
       {
           g.setColor(Color.blue);
           flag = 2;
       } 
       
       else if (flag==2)
       
       {
           
           g.setColor(Color.red);
           flag = 1;
       }
                 
       g.drawLine(10,y,100,y);
       y+=10;
       
       }
       
       
        
       

   }

}
