
package drawshape;

import java.awt.*;
import javax.swing.JApplet;
import java.util.Random;
public class DrawShape2 extends JApplet {
    
int x, z;

int w = 200;
int y;


public void paint(Graphics g){
    super.paint(g);
    

       
    for (x = 0; x<=9; x++)
       {
    int r = (int)(Math.random()*100);
    int gx = (int)(Math.random()*230);
    int b = (int)(Math.random()*150);
    Color c = new Color(r,gx,b);
       g.fillRect(y, y, w, w);
       g.setColor(c);
       w = w - 20;
       y += 10 ;

       }
    
}
    
}