

package drawshape;

import java.awt.*;
import javax.swing.JApplet;

public class DrawShape3 extends JApplet {
    

public void paint(Graphics g){
    super.paint(g);
    
    int x;

    int w = 20;
    int a= 100;
    int y= 100;
    int h= 150;
       
    for (x = 0; x<=9; x++)
       {
        int r = (int)(Math.random()*100);
        int gx = (int)(Math.random()*230);
        int b = (int)(Math.random()*150);
        Color c = new Color(r,gx,b);
        
        for (int delay = 0 ; delay<=50000000; delay++);
        
        g.fillOval(w, y, 100, h);
        g.setColor(c);
        w += 10 ;
        y -= 10 ;
        a += 20 ;
        h += 20;

       }
    
}
    
}