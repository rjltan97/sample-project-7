
package aincrad;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Ains extends javax.swing.JFrame {
int price;
int quan;
String color, size, name, addr, cono;

    public Ains() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        ProfilePanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        NameField = new javax.swing.JTextField();
        AddressField = new javax.swing.JTextField();
        ConField = new javax.swing.JTextField();
        UPField = new javax.swing.JTextField();
        NameLabel = new javax.swing.JLabel();
        AddLabel = new javax.swing.JLabel();
        CoLabel = new javax.swing.JLabel();
        UnitLabel = new javax.swing.JLabel();
        QuanLabel = new javax.swing.JLabel();
        QField = new javax.swing.JTextField();
        PanelColor = new javax.swing.JPanel();
        Red = new javax.swing.JRadioButton();
        Green = new javax.swing.JRadioButton();
        Blue = new javax.swing.JRadioButton();
        ColorLabel = new javax.swing.JLabel();
        PanelSize = new javax.swing.JPanel();
        Small = new javax.swing.JRadioButton();
        Med = new javax.swing.JRadioButton();
        Lar = new javax.swing.JRadioButton();
        SizeLabel = new javax.swing.JLabel();
        Order = new javax.swing.JButton();
        Ext = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aincrad ");

        ProfilePanel.setBackground(new java.awt.Color(255, 255, 255));
        ProfilePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("CUSTOMER PROFILE");

        NameLabel.setText("Name");

        AddLabel.setText("Address");

        CoLabel.setText("Contact No.");

        UnitLabel.setText("Unit Price");

        QuanLabel.setText("Quantity");

        javax.swing.GroupLayout ProfilePanelLayout = new javax.swing.GroupLayout(ProfilePanel);
        ProfilePanel.setLayout(ProfilePanelLayout);
        ProfilePanelLayout.setHorizontalGroup(
            ProfilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProfilePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ProfilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ProfilePanelLayout.createSequentialGroup()
                        .addGroup(ProfilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NameLabel)
                            .addComponent(AddLabel)
                            .addComponent(CoLabel)
                            .addComponent(UnitLabel))
                        .addGap(35, 35, 35)
                        .addGroup(ProfilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(ConField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(AddressField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NameField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 279, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, ProfilePanelLayout.createSequentialGroup()
                                .addComponent(UPField, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(QuanLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(QField, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        ProfilePanelLayout.setVerticalGroup(
            ProfilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProfilePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(ProfilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NameLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ProfilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddressField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ProfilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ConField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CoLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ProfilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(UPField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UnitLabel)
                    .addComponent(QuanLabel)
                    .addComponent(QField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelColor.setBackground(new java.awt.Color(255, 255, 255));
        PanelColor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        Red.setBackground(new java.awt.Color(255, 0, 0));
        buttonGroup1.add(Red);
        Red.setText("Red");
        Red.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                RedItemStateChanged(evt);
            }
        });

        Green.setBackground(new java.awt.Color(255, 0, 0));
        buttonGroup1.add(Green);
        Green.setText("Green");
        Green.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                GreenItemStateChanged(evt);
            }
        });

        Blue.setBackground(new java.awt.Color(255, 0, 0));
        buttonGroup1.add(Blue);
        Blue.setText("Blue");
        Blue.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                BlueItemStateChanged(evt);
            }
        });

        ColorLabel.setText("Color");

        javax.swing.GroupLayout PanelColorLayout = new javax.swing.GroupLayout(PanelColor);
        PanelColor.setLayout(PanelColorLayout);
        PanelColorLayout.setHorizontalGroup(
            PanelColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelColorLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ColorLabel)
                    .addComponent(Green, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Red, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Blue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        PanelColorLayout.setVerticalGroup(
            PanelColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelColorLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ColorLabel)
                .addGap(9, 9, 9)
                .addComponent(Red)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Green)
                .addGap(3, 3, 3)
                .addComponent(Blue)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        PanelSize.setBackground(new java.awt.Color(255, 255, 255));
        PanelSize.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        Small.setBackground(new java.awt.Color(204, 0, 0));
        buttonGroup2.add(Small);
        Small.setText("S");
        Small.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                SmallItemStateChanged(evt);
            }
        });

        Med.setBackground(new java.awt.Color(204, 0, 0));
        buttonGroup2.add(Med);
        Med.setText("M");
        Med.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                MedItemStateChanged(evt);
            }
        });

        Lar.setBackground(new java.awt.Color(204, 0, 0));
        buttonGroup2.add(Lar);
        Lar.setText("L");
        Lar.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                LarItemStateChanged(evt);
            }
        });

        SizeLabel.setText("Size");

        javax.swing.GroupLayout PanelSizeLayout = new javax.swing.GroupLayout(PanelSize);
        PanelSize.setLayout(PanelSizeLayout);
        PanelSizeLayout.setHorizontalGroup(
            PanelSizeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelSizeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelSizeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Med, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SizeLabel)
                    .addComponent(Small, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Lar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        PanelSizeLayout.setVerticalGroup(
            PanelSizeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelSizeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SizeLabel)
                .addGap(9, 9, 9)
                .addComponent(Small)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Med)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Lar)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        Order.setText("Place Order");
        Order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OrderActionPerformed(evt);
            }
        });

        Ext.setText("Exit");
        Ext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ProfilePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(PanelColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(PanelSize, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Ext, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Order, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ProfilePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PanelSize, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(PanelColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Order)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Ext)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ExtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExtActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ExtActionPerformed

    private void RedItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_RedItemStateChanged
        if(evt.getSource()==Red){
            if (evt.getStateChange()== ItemEvent.SELECTED){
            color = "Red";    
            }          
            }
    }//GEN-LAST:event_RedItemStateChanged

    private void GreenItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_GreenItemStateChanged
        if(evt.getSource()==Green){
            if (evt.getStateChange()== ItemEvent.SELECTED){
            color = "Green";    
            }          
            }
    }//GEN-LAST:event_GreenItemStateChanged

    private void BlueItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_BlueItemStateChanged
        if(evt.getSource()==Blue){
            if (evt.getStateChange()== ItemEvent.SELECTED){
            color = "Blue";
            }        
            }
    }//GEN-LAST:event_BlueItemStateChanged

    private void SmallItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_SmallItemStateChanged
        if(evt.getSource()==Small){
            if (evt.getStateChange()== ItemEvent.SELECTED){
                price = 280;
                UPField.setText(Integer.toString(price));
                size = "Small";
            
            }            
            }
    }//GEN-LAST:event_SmallItemStateChanged

    private void MedItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_MedItemStateChanged
        if(evt.getSource()==Med){
            if (evt.getStateChange()== ItemEvent.SELECTED){
                price = 290;
                UPField.setText(Integer.toString(price));
                size = "Medium";
            
            }            
            }
    }//GEN-LAST:event_MedItemStateChanged

    private void LarItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_LarItemStateChanged
        if(evt.getSource()==Lar){
            if (evt.getStateChange()== ItemEvent.SELECTED){
                price = 300;
                UPField.setText(Integer.toString(price));
                size = "Large";
            
            }            
            }
    }//GEN-LAST:event_LarItemStateChanged

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
        int pprice, pqty, total;
        
        pprice = Integer.parseInt(UPField.getText());
        pqty = Integer.parseInt(QField.getText());
        total = pqty*pprice;
        name = NameField.getText();
        addr = AddressField.getText();
        cono = ConField.getText();
        JOptionPane.showMessageDialog(null, "Name: " + name + "\nAddress: " + addr + "\nContact Number: " + cono  + "\nColor: " + color + "\nSize: " + size + "\nTotal Price: " + total, "Alert", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_OrderActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new Ains().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AddLabel;
    private javax.swing.JTextField AddressField;
    private javax.swing.JRadioButton Blue;
    private javax.swing.JLabel CoLabel;
    private javax.swing.JLabel ColorLabel;
    private javax.swing.JTextField ConField;
    private javax.swing.JButton Ext;
    private javax.swing.JRadioButton Green;
    private javax.swing.JRadioButton Lar;
    private javax.swing.JRadioButton Med;
    private javax.swing.JTextField NameField;
    private javax.swing.JLabel NameLabel;
    private javax.swing.JButton Order;
    private javax.swing.JPanel PanelColor;
    private javax.swing.JPanel PanelSize;
    private javax.swing.JPanel ProfilePanel;
    private javax.swing.JTextField QField;
    private javax.swing.JLabel QuanLabel;
    private javax.swing.JRadioButton Red;
    private javax.swing.JLabel SizeLabel;
    private javax.swing.JRadioButton Small;
    private javax.swing.JTextField UPField;
    private javax.swing.JLabel UnitLabel;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
