/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nameapplet;

import javax.swing.JApplet;
import java.awt.*;
public class NameApplet3 extends JApplet {
    
    Font header = new Font("SansSerif", Font.BOLD, 24);
    String text, text2, text3;
    int delayLimit;
    boolean flag1=false, flag2=true;
		
    @Override
    public void init() {
	text = "Robin Tan";
        text2 = "Haruhiko";
        
	delayLimit = 50000000;
    }
	
    @Override
    public void paint(Graphics g) {
        int y2= 200;
	g.setFont(header);
	for(int y = 0; y < 30; y++) {
            //user-defined delay function
            
            for(int delay =0; delay < delayLimit; delay++);
            g.setColor(new Color(255, 255, 255));	//white
            g.fillRect(y, 0, 500, 100);
            if(flag1=false){
                g.setColor(new Color(0, 0, 0));
                flag1=true;
            }else{
                g.setColor(new Color(0, 0, 0));
                flag1=false;
            }
            	//black
            for(int delay =0; delay < delayLimit; delay++);
            g.drawString(text, y+1, 20);

                      	     
            //user-defined delay function
            for(int delay =0; delay < delayLimit; delay++);
            g.setColor(new Color(255, 255, 255));	//white
            g.fillRect(y2--, 0, 500, 100);
            if(flag2=false){
                g.setColor(new Color(0, 0, 0));
                flag2=true;
            }else{
                g.setColor(new Color(255, 0, 0));
                flag2=false;
            }	//black
            g.drawString(text2, y2-1, 20);
   
	}               
    }   
}