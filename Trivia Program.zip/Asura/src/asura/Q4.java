//correct lambo
package asura;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
public class Q4 extends javax.swing.JFrame {

    ImageIcon log[]=
    {
        new ImageIcon("La.jpg")
    };
    public Q4() {
        initComponents();
        Im.setIcon((log[0]));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        ja = new javax.swing.JRadioButton();
        ni = new javax.swing.JRadioButton();
        zu = new javax.swing.JRadioButton();
        lambo = new javax.swing.JRadioButton();
        jPanel1 = new javax.swing.JPanel();
        Im = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        nxt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Question 4");

        buttonGroup1.add(ja);
        ja.setText("JAGUAR");
        ja.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jaItemStateChanged(evt);
            }
        });

        buttonGroup1.add(ni);
        ni.setText("NISSAN");
        ni.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                niItemStateChanged(evt);
            }
        });

        buttonGroup1.add(zu);
        zu.setText("SUZUKI");
        zu.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                zuItemStateChanged(evt);
            }
        });

        buttonGroup1.add(lambo);
        lambo.setText("LAMBORGHINI");
        lambo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                lamboItemStateChanged(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        Im.setText("jLabel1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Im, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Im, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
        );

        jLabel2.setText("WHAT VEHICLE IS THIS?");

        nxt.setText("NEXT");
        nxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nxtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lambo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(nxt))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ja)
                            .addComponent(ni)
                            .addComponent(zu)
                            .addComponent(jLabel2))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addGap(6, 6, 6)
                .addComponent(ja)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ni)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(zu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lambo)
                    .addComponent(nxt))
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nxtActionPerformed
        // TODO add your handling code here:
         this.setVisible(false);
        new Q5().setVisible(true);
    }//GEN-LAST:event_nxtActionPerformed

    private void jaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jaItemStateChanged
        // TODO add your handling code here:
        ja.setEnabled(false);
        ni.setEnabled(false);
        zu.setEnabled(false);
        lambo.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_jaItemStateChanged

    private void niItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_niItemStateChanged
        // TODO add your handling code here:
        ja.setEnabled(false);
        ni.setEnabled(false);
        zu.setEnabled(false);
        lambo.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_niItemStateChanged

    private void zuItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_zuItemStateChanged
        // TODO add your handling code here:
        ja.setEnabled(false);
        ni.setEnabled(false);
        zu.setEnabled(false);
        lambo.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_zuItemStateChanged

    private void lamboItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_lamboItemStateChanged
        // TODO add your handling code here:
        ja.setEnabled(false);
        ni.setEnabled(false);
        zu.setEnabled(false);
        lambo.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Correct!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(1);
        nxt.setEnabled(true);
    }//GEN-LAST:event_lamboItemStateChanged


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Q4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Q4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Q4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Q4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Q4().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Im;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton ja;
    private javax.swing.JRadioButton lambo;
    private javax.swing.JRadioButton ni;
    private javax.swing.JButton nxt;
    private javax.swing.JRadioButton zu;
    // End of variables declaration//GEN-END:variables
}
