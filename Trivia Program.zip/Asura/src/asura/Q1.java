//Correct Answer is BMW
package asura;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;

public class Q1 extends javax.swing.JFrame  {
    ImageIcon log[]=
    {
        new ImageIcon("Bmw.jpg")
    };

    public Q1() {
        initComponents();
        Im.setIcon((log[0]));
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        bm = new javax.swing.JRadioButton();
        ho = new javax.swing.JRadioButton();
        to = new javax.swing.JRadioButton();
        mi = new javax.swing.JRadioButton();
        jPanel1 = new javax.swing.JPanel();
        Im = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        nxt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Question 1");

        buttonGroup1.add(bm);
        bm.setText("BMW");
        bm.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                bmItemStateChanged(evt);
            }
        });

        buttonGroup1.add(ho);
        ho.setText("HONDA");
        ho.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                hoItemStateChanged(evt);
            }
        });

        buttonGroup1.add(to);
        to.setText("TOYOTA");
        to.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                toItemStateChanged(evt);
            }
        });

        buttonGroup1.add(mi);
        mi.setText("MITSUBISHI");
        mi.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                miItemStateChanged(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        Im.setText("jLabel1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Im, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Im, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
        );

        jLabel2.setText("WHAT VEHICLE IS THIS?");

        nxt.setText("NEXT");
        nxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nxtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bm)
                            .addComponent(ho)
                            .addComponent(to)
                            .addComponent(jLabel2))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(mi)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(nxt)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addGap(6, 6, 6)
                .addComponent(bm)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ho)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(to)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mi)
                    .addComponent(nxt))
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bmItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_bmItemStateChanged
        bm.setEnabled(false);
        ho.setEnabled(false);
        to.setEnabled(false);
        mi.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Correct!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(1);
        nxt.setEnabled(true);
    }//GEN-LAST:event_bmItemStateChanged

    private void hoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_hoItemStateChanged
        // TODO add your handling code here:
        bm.setEnabled(false);
        ho.setEnabled(false);
        to.setEnabled(false);
        mi.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_hoItemStateChanged

    private void toItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_toItemStateChanged
        // TODO add your handling code here:
        bm.setEnabled(false);
        ho.setEnabled(false);
        to.setEnabled(false);
        mi.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_toItemStateChanged

    private void miItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_miItemStateChanged
        // TODO add your handling code here:
        bm.setEnabled(false);
        ho.setEnabled(false);
        to.setEnabled(false);
        mi.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_miItemStateChanged

    private void nxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nxtActionPerformed
        // next
        
         this.setVisible(false);
        new Q2().setVisible(true);
    }//GEN-LAST:event_nxtActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Q1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Q1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Q1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Q1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Q1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Im;
    private javax.swing.JRadioButton bm;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton ho;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton mi;
    private javax.swing.JButton nxt;
    private javax.swing.JRadioButton to;
    // End of variables declaration//GEN-END:variables
}
