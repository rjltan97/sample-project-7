
package asura;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
public class Q6 extends javax.swing.JFrame {

    ImageIcon log[]=
    {
        new ImageIcon("Me.jpg")
    };
    public Q6() {
        initComponents();
        Im.setIcon((log[0]));
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        cad = new javax.swing.JRadioButton();
        mb = new javax.swing.JRadioButton();
        rr = new javax.swing.JRadioButton();
        dod = new javax.swing.JRadioButton();
        jPanel1 = new javax.swing.JPanel();
        Im = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        nxt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Question 6");

        buttonGroup1.add(cad);
        cad.setText("CADILLAC");
        cad.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cadItemStateChanged(evt);
            }
        });

        buttonGroup1.add(mb);
        mb.setText("MERCEDEZ BENZ");
        mb.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                mbItemStateChanged(evt);
            }
        });

        buttonGroup1.add(rr);
        rr.setText("ROLLS ROYCE");
        rr.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rrItemStateChanged(evt);
            }
        });

        buttonGroup1.add(dod);
        dod.setText("DODGE");
        dod.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                dodItemStateChanged(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        Im.setText("jLabel1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Im, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Im, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
        );

        jLabel2.setText("WHAT VEHICLE IS THIS?");

        nxt.setText("NEXT");
        nxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nxtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(dod)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(nxt))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cad)
                            .addComponent(mb)
                            .addComponent(rr)
                            .addComponent(jLabel2))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addGap(6, 6, 6)
                .addComponent(cad)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mb)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rr, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dod)
                    .addComponent(nxt))
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nxtActionPerformed
        // TODO add your handling code here:
         this.setVisible(false);
        new Results().setVisible(true);
    }//GEN-LAST:event_nxtActionPerformed

    private void cadItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cadItemStateChanged
        // TODO add your handling code here:
        cad.setEnabled(false);
        mb.setEnabled(false);
        rr.setEnabled(false);
        dod.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_cadItemStateChanged

    private void mbItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_mbItemStateChanged
        // TODO add your handling code here:
        cad.setEnabled(false);
        mb.setEnabled(false);
        rr.setEnabled(false);
        dod.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Correct!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(1);
        nxt.setEnabled(true);
    }//GEN-LAST:event_mbItemStateChanged

    private void rrItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rrItemStateChanged
        // TODO add your handling code here:
        cad.setEnabled(false);
        mb.setEnabled(false);
        rr.setEnabled(false);
        dod.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_rrItemStateChanged

    private void dodItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_dodItemStateChanged
        // TODO add your handling code here:
        cad.setEnabled(false);
        mb.setEnabled(false);
        rr.setEnabled(false);
        dod.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_dodItemStateChanged


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Q6.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Q6.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Q6.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Q6.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Q6().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Im;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton cad;
    private javax.swing.JRadioButton dod;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton mb;
    private javax.swing.JButton nxt;
    private javax.swing.JRadioButton rr;
    // End of variables declaration//GEN-END:variables
}
