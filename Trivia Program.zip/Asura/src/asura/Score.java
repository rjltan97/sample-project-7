
package asura;

public abstract class Score {
    private static int total;
    
    public static void sc(int point)
    {
       total += point;
       getsc(total);
    }
    
    public static int getsc(int point)
    {
        return total;
    }
    
}
