//correct ans is suba
package asura;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
public class Q3 extends javax.swing.JFrame {

    ImageIcon log[]=
    {
        new ImageIcon("Su.jpg")
    };
    public Q3() {
        initComponents();
        Im.setIcon((log[0]));
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        ben = new javax.swing.JRadioButton();
        suba = new javax.swing.JRadioButton();
        mcl = new javax.swing.JRadioButton();
        aum = new javax.swing.JRadioButton();
        jPanel1 = new javax.swing.JPanel();
        Im = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        nxt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Question 3");

        buttonGroup1.add(ben);
        ben.setText("BENTLEY");
        ben.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                benItemStateChanged(evt);
            }
        });

        buttonGroup1.add(suba);
        suba.setText("SUBARU");
        suba.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                subaItemStateChanged(evt);
            }
        });

        buttonGroup1.add(mcl);
        mcl.setText("MCLAREN");
        mcl.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                mclItemStateChanged(evt);
            }
        });

        buttonGroup1.add(aum);
        aum.setText("AUSTIN MARTIN");
        aum.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                aumItemStateChanged(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        Im.setText("jLabel1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Im, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Im, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
        );

        jLabel2.setText("WHAT VEHICLE IS THIS?");

        nxt.setText("NEXT");
        nxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nxtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(aum)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(nxt))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ben)
                            .addComponent(suba)
                            .addComponent(mcl)
                            .addComponent(jLabel2)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addGap(6, 6, 6)
                .addComponent(ben)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(suba)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mcl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(aum)
                    .addComponent(nxt))
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nxtActionPerformed
        // 
         this.setVisible(false);
        new Q4().setVisible(true);
    }//GEN-LAST:event_nxtActionPerformed

    private void benItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_benItemStateChanged
        // TODO add your handling code here:
        ben.setEnabled(false);
        suba.setEnabled(false);
        mcl.setEnabled(false);
        aum.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_benItemStateChanged

    private void subaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_subaItemStateChanged
        // TODO add your handling code here:
        ben.setEnabled(false);
        suba.setEnabled(false);
        mcl.setEnabled(false);
        aum.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Correct!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(1);
        nxt.setEnabled(true);
    }//GEN-LAST:event_subaItemStateChanged

    private void mclItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_mclItemStateChanged
        // TODO add your handling code here:
        ben.setEnabled(false);
        suba.setEnabled(false);
        mcl.setEnabled(false);
        aum.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
        Score.sc(0);
        nxt.setEnabled(true);
    }//GEN-LAST:event_mclItemStateChanged

    private void aumItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_aumItemStateChanged
        // TODO add your handling code here:
        ben.setEnabled(false);
        suba.setEnabled(false);
        mcl.setEnabled(false);
        aum.setEnabled(false);
       JOptionPane.showMessageDialog(null, "Wrong!", "Information", JOptionPane.INFORMATION_MESSAGE);
       Score.sc(0);
       nxt.setEnabled(true);
    }//GEN-LAST:event_aumItemStateChanged


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Q3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Q3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Q3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Q3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Q3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Im;
    private javax.swing.JRadioButton aum;
    private javax.swing.JRadioButton ben;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton mcl;
    private javax.swing.JButton nxt;
    private javax.swing.JRadioButton suba;
    // End of variables declaration//GEN-END:variables
}
