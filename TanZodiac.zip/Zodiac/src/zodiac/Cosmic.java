
package zodiac;

import javax.swing.*;
import java.awt.*;
public class Cosmic extends javax.swing.JFrame {
    
    ImageIcon log[] ={
    new ImageIcon("Aqua.jpg"),
    new ImageIcon("Aries.jpg"),
    new ImageIcon("Canc.jpg"),
    new ImageIcon("Capri.jpg"),
    new ImageIcon("Gem.jpg"),
    new ImageIcon("Leo.jpg"),
    new ImageIcon("Lib.jpg"),
    new ImageIcon("Pis.jpg"),
    new ImageIcon("Sag.jpg"),
    new ImageIcon("Sco.jpg"),
    new ImageIcon("Tau.jpg"),
    new ImageIcon("Vir.jpg"),
};

    public Cosmic() {
        initComponents();
        
        for(int i = 1; i<=31; i++){
            DAY.addItem(i);
        }
        DAY.setSelectedIndex(0);
        
        for(int i= 1950; i<=2016; i++){
            YEAR.addItem(i);        
        }
        YEAR.setSelectedIndex(0);
    }
        


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PANEL = new javax.swing.JPanel();
        TITLE = new javax.swing.JLabel();
        MONTH = new javax.swing.JComboBox();
        DAY = new javax.swing.JComboBox();
        YEAR = new javax.swing.JComboBox();
        Find = new javax.swing.JButton();
        IMG = new javax.swing.JLabel();
        TXT = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ZODIAC APP");

        PANEL.setBackground(new java.awt.Color(255, 255, 255));

        TITLE.setFont(new java.awt.Font("Rod", 1, 18)); // NOI18N
        TITLE.setText("ZODIAC APPLICATION");

        MONTH.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" }));

        Find.setText("FIND ZODIAC");
        Find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FindActionPerformed(evt);
            }
        });

        IMG.setBackground(new java.awt.Color(204, 0, 0));
        IMG.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        IMG.setOpaque(true);

        TXT.setBackground(new java.awt.Color(153, 0, 0));
        TXT.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TXT.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TXT.setOpaque(true);

        javax.swing.GroupLayout PANELLayout = new javax.swing.GroupLayout(PANEL);
        PANEL.setLayout(PANELLayout);
        PANELLayout.setHorizontalGroup(
            PANELLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PANELLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PANELLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TITLE)
                    .addGroup(PANELLayout.createSequentialGroup()
                        .addComponent(IMG, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(TXT, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE))
                    .addGroup(PANELLayout.createSequentialGroup()
                        .addComponent(MONTH, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(DAY, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(YEAR, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(Find)))
                .addContainerGap())
        );
        PANELLayout.setVerticalGroup(
            PANELLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PANELLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TITLE)
                .addGap(18, 18, 18)
                .addGroup(PANELLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MONTH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DAY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(YEAR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Find))
                .addGap(32, 32, 32)
                .addGroup(PANELLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(IMG, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TXT, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(67, 67, 67))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PANEL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PANEL, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void FindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FindActionPerformed
        // TODO add your handling code here:
        Object month = MONTH.getSelectedItem();
        Object day = DAY.getSelectedItem();
        Object year = YEAR.getSelectedItem();
        
        String mm = (String) month;
        int dd = (int) day;
        int yy = (int) year;
        
        if(mm.equals("January")){
            if (dd >=1 && dd <=19){
            displayCapInfo();
            } else if (dd>=20 && dd<=31){
            displayAquInfo();         
            }
        } else if(mm.equals("February")){
            if (dd >=1 && dd <=18){
            displayAquInfo();
            } else if (dd>=19 && dd<=31){
            displayPisInfo();         
            }
        } else if(mm.equals("March")){
            if (dd >=1 && dd <=20){
            displayPisInfo();    
            } else if (dd>=21 && dd<=31){
            displayAriInfo();         
            }
        } else if(mm.equals("April")){
            if (dd >=1 && dd <=19){
            displayAriInfo();    
            } else if (dd>=20 && dd<=31){
            displayTauInfo();         
            }
        } else if(mm.equals("May")){
            if (dd >=1 && dd <=20){
            displayTauInfo();    
            } else if (dd>=21 && dd<=31){
            displayGemInfo();         
            }
        } else if(mm.equals("June")){
            if (dd >=1 && dd <=20){
            displayGemInfo();    
            } else if (dd>=21 && dd<=31){
            displayCanInfo();         
            }
        } else if(mm.equals("July")){
            if (dd >=1 && dd <=22){
            displayCanInfo();    
            } else if (dd>=23 && dd<=31){
            displayLeoInfo();       
            }
        } else if(mm.equals("August")){
            if (dd >=1 && dd <=22){
            displayLeoInfo();    
            } else if (dd>=23 && dd<=31){
            displayVirInfo();         
            }
        } else if(mm.equals("September")){
            if (dd >=1 && dd <=22){
            displayVirInfo();     
            } else if (dd>=23 && dd<=31){
            displayLibInfo();         
            }
        } else if(mm.equals("October")){
            if (dd >=1 && dd <=22){
            displayLibInfo();    
            } else if (dd>=23 && dd<=31){
            displayScoInfo();    
            }
        } else if(mm.equals("November")){
            if (dd >=1 && dd <=21){
            displayScoInfo();    
            } else if (dd>=22 && dd<=31){
            displaySagInfo();         
            }
        } else if(mm.equals("December")){
            if (dd >=1 && dd <=21){
            displaySagInfo();    
            } else if (dd>=22 && dd<=31){
            displayCapInfo();        
            }
        } else {
            //INVALID DATE RANGE
            
        }
    }//GEN-LAST:event_FindActionPerformed

    //USER DEF FUNCTIONS
    public void displaySagInfo(){
        //later
        IMG.setIcon(log[8]);
        TXT.setText("<html><center>Characteristics [SAGITTARIUS]:<br>Philosophical</br><br>Optimism</br></html></center>");
    }
    public void displayPisInfo(){
        IMG.setIcon(log[7]);
        TXT.setText("<html><center>Characteristics [PISCES]:<br>Indecisive</br><br>Imagination</br></html></center>");
    }
    public void displayLeoInfo(){
        IMG.setIcon(log[5]);
        TXT.setText("<html><center>Characteristics [LEO]:<br>Warmth</br><br>Generosity</br></html></center>");
    } 
    public void displayGemInfo(){
        IMG.setIcon(log[4]);
        TXT.setText("<html><center>Characteristics [GEMINI]:<br>Inquisitive</br><br>Intelligent</br></html></center>");
    } 
    public void displayAquInfo(){
        IMG.setIcon(log[0]);
        TXT.setText("<html><center>Characteristics [AQUARIUS]:<br>Knowledge</br><br>Humanitarian</br></html></center>");
    }
    public void displayCanInfo(){
        IMG.setIcon(log[2]);
        TXT.setText("<html><center>Characteristics [CANCER]:<br>Impulsive</br><br>Emotion</br></html></center>");
    }
    public void displayAriInfo(){
        IMG.setIcon(log[1]);
        TXT.setText("<html><center>Characteristics [ARIES]:<br>Active</br><br>Demanding</br></html></center>");
    }
    public void displayScoInfo(){
        IMG.setIcon(log[9]);
        TXT.setText("<html><center>Characteristics [SCORPIO]:<br>Transient</br><br>Unyielding</br></html></center>");
    }
    public void displayLibInfo(){
        IMG.setIcon(log[6]);
        TXT.setText("<html><center>Characteristics [LIBRA]:<br>Truth</br><br>Perfection</br></html></center>");
    }
    public void displayVirInfo(){
        IMG.setIcon(log[11]);
        TXT.setText("<html><center>Characteristics [VIRGO]:<br>Practical</br><br>Reflective</br></html></center>");
    }
    public void displayCapInfo(){
        IMG.setIcon(log[3]);
        TXT.setText("<html><center>Characteristics [CAPRICORN]:<br>Dominance</br><br>Persevering</br></html></center>");
    }
    public void displayTauInfo(){
        IMG.setIcon(log[10]);
        TXT.setText("<html><center>Characteristics [TAURUS]:<br>Security</br><br>Subtle</br></html></center>");
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new Cosmic().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox DAY;
    private javax.swing.JButton Find;
    private javax.swing.JLabel IMG;
    private javax.swing.JComboBox MONTH;
    private javax.swing.JPanel PANEL;
    private javax.swing.JLabel TITLE;
    private javax.swing.JLabel TXT;
    private javax.swing.JComboBox YEAR;
    // End of variables declaration//GEN-END:variables
}
