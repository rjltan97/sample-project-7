
package zodiac;


public class Zodiac {


    public static void main(String[] args) {
     
    }
}
