Imports System.Data
Imports System.Data.OleDb
Imports System.Collections
Imports System.IO

Public Class Form1
    Dim da As New OleDbDataAdapter
    Dim aa As New OleDb.OleDbDataAdapter
    Dim ds As New DataSet
    Dim SQLstr As String
    Dim maxrow As Integer
    Dim command As OleDbCommand
    Dim icount As Integer
    Dim usrSW As Integer
    Dim eda As New OleDbDataAdapter
    Dim eds As New DataSet
    Dim dda As New OleDbDataAdapter
    Dim dds As New DataSet
    Dim icheck As New Integer
    Dim squery As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\RLT_FINALS\DBC\Data.mdb"
        Panel1.Left = 157
        Panel1.Top = 125
        Panel2.Left = 117
        Panel2.Top = 32
        Panel3.Left = 71
        Panel3.Top = 80
        Panel5.Left = 7
        Panel5.Top = 43
        LabelTitle.Left = 12
        LabelTitle.Top = 37
    End Sub

    Private Sub LogIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogIn.Click
        Panel1.Visible = True
        LabelTitle.Visible = True
        TxtUserID.Focus()
    End Sub

    Private Sub LogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogOut.Click
        LabelTitle.Visible = True
        LogIn.Enabled = True
        LogOut.Enabled = False
        STua.Enabled = False
        Panel1.Visible = False
        Panel2.Visible = False
        Panel3.Visible = False
        Panel5.Visible = False
        Panel4.Visible = False
        TxtUserID.Clear()
        TxtPass.Clear()
    End Sub

    Private Sub Quit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Quit.Click
        Me.Close()
    End Sub

    Private Sub NewUserToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewUserToolStripMenuItem1.Click
        LabelTitle.Visible = False
        Panel1.Visible = False
        Panel2.Visible = True
        Panel3.Enabled = True
        clearup()
        Panel5.Visible = False
        Panel4.Visible = True
        usrSW = 1 'for adding new reservation'
        LblRem.Text = "New Reservation"
    End Sub

    Private Sub EditUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditUser.Click
        LabelTitle.Visible = False
        Panel1.Visible = False
        Panel2.Visible = True
        Panel4.Visible = True
        Panel3.Enabled = True
        Panel5.Visible = False
        usrSW = 2 'for editing reservations'
        LblRem.Text = "Edit Reservation"
    End Sub

    Private Sub DeleteUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteUser.Click
        LabelTitle.Visible = False
        Panel1.Visible = False
        Panel2.Visible = True
        Panel3.Enabled = False
        Panel5.Visible = False
        usrSW = 3 'for deleting'
        LblRem.Text = "Delete Reservation"
    End Sub

    Private Sub ViewUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewUser.Click
        LabelTitle.Visible = False
        Panel1.Visible = False
        Panel2.Visible = True
        Panel3.Enabled = False
        Panel5.Visible = False
        usrSW = 4 'for viewing'
        LblRem.Text = "View Reservation"
    End Sub

    Private Sub BtnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnOK.Click
        con.Open()
        ds.Clear()
        SQLstr = "SELECT * FROM Userfle WHERE UserID = '" & TxtUserID.Text & "'"
        da = New OleDb.OleDbDataAdapter(SQLstr, con)
        da.Fill(ds, "USR")
        con.Close()
        maxrow = ds.Tables("USR").Rows.Count
        If maxrow > 0 Then

            If ds.Tables("USR").Rows(0).Item(1) = TxtPass.Text Then
                MsgBox("Welcome to Asiimov Airline Reservation", MsgBoxStyle.Information, "Message")
                STua.Enabled = True
                Panel1.Visible = False
                LogIn.Enabled = False
                LogOut.Enabled = True

                Exit Sub
            Else
                MsgBox("Invalid Password. Please Try Again!", MsgBoxStyle.Critical, "Message")
                TxtPass.Text = ""
                TxtPass.Focus()
                Exit Sub
            End If

        Else
            MsgBox("Invalid User ID. Please Try Again!", MsgBoxStyle.Critical, "Message")
            TxtUserID.Text = ""
            TxtUserID.Focus()
        End If

    End Sub

    Private Sub clearup()
        TxtLast.Clear()
        TxtFirst.Clear()
        TxtMid.Clear()
        TxtUsrPass.Clear()
        CmbFlag.Text = ""
        TxtFl.Clear()
        TxtCl.Clear()
        TxtSeat.Clear()
    End Sub

    Private Sub TxtUsrID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtUsrID.KeyPress
        Panel3.Visible = False
    End Sub

    Private Sub TxtUsrID_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtUsrID.KeyUp
        If e.KeyCode = 222 Then
            MsgBox("Invalid character entry. Please try again", MsgBoxStyle.Exclamation, "Alert")
            TxtUsrID.Text = ""
            TxtUsrID.Focus()
            Exit Sub
        End If
    End Sub


    Private Sub BtnUsrSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnUsrSearch.Click
        If TxtUsrID.Text = "" Then
            TxtUsrID.Focus()
            Exit Sub
        End If
        If usrSW = 1 Then 'New User'
            con.Open()
            ds.Clear()
            SQLstr = "SELECT * FROM Userfle WHERE UserID = '" & TxtUsrID.Text & "'"
            da = New OleDb.OleDbDataAdapter(SQLstr, con)
            da.Fill(ds, "USR")
            con.Close()
            maxrow = ds.Tables("USR").Rows.Count
            If maxrow > 0 Then
                MsgBox("Record already exists in the User File. Please try again.", MsgBoxStyle.Information, "Alert")
                Exit Sub
                TxtUsrID.Focus()
            End If

            Call clearup()
            Panel3.Visible = True
            TxtLast.Focus()
        End If

        If usrSW = 2 Then 'Edit User'
            Dim icmdeq As New OleDbCommand
            con.Open()
            eds.Clear()
            SQLstr = "SELECT * FROM Userfle WHERE UserID = '" & TxtUsrID.Text & "'"
            eda = New OleDb.OleDbDataAdapter(SQLstr, con)
            eda.Fill(eds, "USR")
            con.Close()
            maxrow = eds.Tables("USR").Rows.Count
            If maxrow = 0 Then
                MsgBox("Record does not exist in the User File. Please try again.", MsgBoxStyle.Information, "Alert")
                Exit Sub
                TxtUsrID.Focus()
                Panel4.Visible = True
            End If
            Panel4.Enabled = True
            Panel3.Enabled = True
            Call clearup()
            TxtUsrPass.Text = eds.Tables("USR").Rows(0).Item(1)
            TxtLast.Text = eds.Tables("USR").Rows(0).Item(2)
            TxtFirst.Text = eds.Tables("USR").Rows(0).Item(3)
            TxtMid.Text = eds.Tables("USR").Rows(0).Item(4)
            CmbFlag.Text = eds.Tables("USR").Rows(0).Item(5)
            TxtFl.Text = eds.Tables("USR").Rows(0).Item(6)
            TxtCl.Text = eds.Tables("USR").Rows(0).Item(7)
            DateTimePicker1.Text = eds.Tables("USR").Rows(0).Item(8)
            TxtSeat.Text = eds.Tables("USR").Rows(0).Item(9)

            Panel3.Visible = True
            TxtLast.Focus()
        End If

        If usrSW = 3 Then 'Deletion'
            con.Open()
            eds.Clear()
            SQLstr = "SELECT * FROM Userfle WHERE UserID = '" & TxtUsrID.Text & "'"
            eda = New OleDb.OleDbDataAdapter(SQLstr, con)
            eda.Fill(eds, "USR")
            con.Close()
            maxrow = eds.Tables("USR").Rows.Count
            If maxrow = 0 Then
                MsgBox("Record does not exist in the User File. Please try again.", MsgBoxStyle.Information, "Alert")
                Exit Sub
                TxtUsrID.Focus()
                Panel4.Visible = True
            End If

            Panel3.Enabled = False
            Panel4.Enabled = False

            Call clearup()
            TxtUsrPass.Text = eds.Tables("USR").Rows(0).Item(1)
            TxtLast.Text = eds.Tables("USR").Rows(0).Item(2)
            TxtFirst.Text = eds.Tables("USR").Rows(0).Item(3)
            TxtMid.Text = eds.Tables("USR").Rows(0).Item(4)
            CmbFlag.Text = eds.Tables("USR").Rows(0).Item(5)
            TxtFl.Text = eds.Tables("USR").Rows(0).Item(6)
            TxtCl.Text = eds.Tables("USR").Rows(0).Item(7)
            DateTimePicker1.Text = eds.Tables("USR").Rows(0).Item(8)
            TxtSeat.Text = eds.Tables("USR").Rows(0).Item(9)
            Panel3.Visible = True
            TxtLast.Focus()
            Panel4.Visible = False

            Dim x As Integer
            x = MsgBox("Are you sure you want to erase this record?", MsgBoxStyle.YesNo)
            'MsgBox(x)

            If x = 7 Then
                MsgBox("Record deletion is ignored!", MsgBoxStyle.Information, "Message")
                Panel3.Visible = False
                TxtUsrID.Focus()
            Else
                con.Open()
                dds.Clear()
                SQLstr = "DELETE * FROM Userfle WHERE UserID = '" & TxtUsrID.Text & "'"
                dda = New OleDb.OleDbDataAdapter(SQLstr, con)
                dda.Fill(dds, "DEL")
                con.Close()
                MsgBox("Record has been deleted. Thank you", MsgBoxStyle.Information, "Message")

            End If
        End If

        If usrSW = 4 Then 'Viewing'
            con.Open()
            eds.Clear()
            SQLstr = "SELECT * FROM Userfle WHERE UserID = '" & TxtUsrID.Text & "'"
            eda = New OleDb.OleDbDataAdapter(SQLstr, con)
            eda.Fill(eds, "USR")
            con.Close()
            maxrow = eds.Tables("USR").Rows.Count
            If maxrow = 0 Then
                MsgBox("Record does not exist in the User File. Please try again.", MsgBoxStyle.Information, "Alert")
                Exit Sub
                TxtUsrID.Focus()
                Panel4.Visible = True
            End If

            Panel3.Enabled = False
            Panel4.Enabled = False

            Call clearup()
            TxtUsrPass.Text = eds.Tables("USR").Rows(0).Item(1)
            TxtLast.Text = eds.Tables("USR").Rows(0).Item(2)
            TxtFirst.Text = eds.Tables("USR").Rows(0).Item(3)
            TxtMid.Text = eds.Tables("USR").Rows(0).Item(4)
            CmbFlag.Text = eds.Tables("USR").Rows(0).Item(5)
            TxtFl.Text = eds.Tables("USR").Rows(0).Item(6)
            TxtCl.Text = eds.Tables("USR").Rows(0).Item(7)
            DateTimePicker1.Text = eds.Tables("USR").Rows(0).Item(8)
            TxtSeat.Text = eds.Tables("USR").Rows(0).Item(9)

            Panel3.Visible = True
            TxtLast.Focus()
            Panel4.Visible = False
        End If

    End Sub


    Private Sub BtnUsrSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnUsrSave.Click
        If TxtLast.Text = "" Then
            MsgBox("The last name is empty. Please fill it up.", MsgBoxStyle.Information, "Alert")
            TxtLast.Focus()
            Exit Sub
        End If

        If TxtFirst.Text = "" Then
            MsgBox("The first name is empty. Please fill it up.", MsgBoxStyle.Information, "Alert")
            TxtFirst.Focus()
            Exit Sub
        End If

        If TxtMid.Text = "" Then
            MsgBox("The mid name is empty. Please fill it up.", MsgBoxStyle.Information, "Alert")
            TxtMid.Focus()
            Exit Sub
        End If

        If TxtUsrPass.Text = "" Then
            MsgBox("The password is empty. Please fill it up.", MsgBoxStyle.Information, "Alert")
            TxtUsrPass.Focus()
            Exit Sub
        End If

        If TxtFl.Text = "" Then
            MsgBox("The Access Field is empty. Please fill it up.", MsgBoxStyle.Information, "Alert")
            TxtLast.Focus()
            Exit Sub
        End If

        If TxtSeat.Text = "" Then
            MsgBox("The Account Status is empty. Please fill it up.", MsgBoxStyle.Information, "Alert")
            TxtLast.Focus()
            Exit Sub
        End If

        If usrSW = 1 Then 'for adding'
            con.Open()
            ds.Clear()
            SQLstr = "SELECT * FROM Userfle WHERE UserID = '" & TxtUsrID.Text & "'"
            da = New OleDb.OleDbDataAdapter(SQLstr, con)
            da.Fill(ds, "USR")
            maxrow = ds.Tables("USR").Rows.Count
            If maxrow > 0 Then
                MsgBox("Record already exists in the User File. Please try again.", MsgBoxStyle.Information, "Alert")
                con.Close()
                Exit Sub
                TxtUsrID.Focus()
            End If
            Try
                SQLstr = "INSERT into Userfle values('" & TxtUsrID.Text & "', '" & TxtUsrPass.Text & "', '" & TxtLast.Text & "', '" & TxtFirst.Text & "', '" & TxtMid.Text & "', '" & CmbFlag.Text & "', '" & TxtFl.Text & "', '" & TxtCl.Text & "', '" & DateTimePicker1.Text & "', '" & TxtSeat.Text & "')"
                command = New OleDbCommand(SQLstr, con)
                icount = command.ExecuteNonQuery
                con.Close()
                MsgBox("Record has been saved", MsgBoxStyle.Information, "Alert")
            Catch ex As Exception
                MsgBox(ex.Message)


            End Try
        End If

        If usrSW = 2 Then 'for editing'
            Dim icmdeq As New OleDbCommand
            con.Open()
            ds.Clear()
            SQLstr = "SELECT * FROM Userfle WHERE UserID = '" & TxtUsrID.Text & "'"
            da = New OleDb.OleDbDataAdapter(SQLstr, con)
            da.Fill(ds, "USR")
            maxrow = ds.Tables("USR").Rows.Count
            If maxrow = 0 Then
                MsgBox("Record does not exist in the User File. Please try again.", MsgBoxStyle.Information, "Alert")
                con.Close()
                Exit Sub
                TxtUsrID.Focus()
            End If
            con.Close()


            If MsgBox("Are you sure you want to edit?" + TxtUsrID.Text + "?", MsgBoxStyle.OkCancel, "Message") = MsgBoxResult.Cancel Then
                'do nothing'
            Else

                Try
                    con.Open()
                    icmdeq = con.CreateCommand
                    icmdeq.CommandText = "UPDATE Userfle SET Pass = '" & TxtUsrPass.Text & "', LastName = '" & TxtLast.Text & "', FirstName = '" & TxtFirst.Text & "', MidName = '" & TxtMid.Text & "', Gender = '" & CmbFlag.Text & "', FgtNm = '" & TxtFl.Text & "', FgtCl = '" & TxtCl.Text & "', FgtDate = '" & DateTimePicker1.Text & "', SeatNumber = '" & TxtSeat.Text & "'WHERE UserID = '" & TxtUsrID.Text & "'"
                    icheck = icmdeq.ExecuteReader.RecordsAffected()

                    If Not icheck > 0 Then
                        MsgBox("Editing Failed!", MsgBoxStyle.Critical, "Alert")
                        Exit Sub
                    End If
                    con.Close()
                    MsgBox("Record has been edited", MsgBoxStyle.Information, "Alert")

                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            End If
        End If

    End Sub

    Private Sub Rprt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rprt.Click
        Form2.Show()
    End Sub

    Private Sub ListView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView.Click
        LabelTitle.Visible = False
        Panel1.Visible = False
        Panel2.Visible = False
        Panel3.Enabled = False
        Panel4.Visible = False
        Panel5.Visible = True
        LblRem2.Text = "Reserved Flights"
    End Sub

    Private Sub BtnUsrCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnUsrCancel.Click

    End Sub

    Private Sub BtnShow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnShow.Click
        Dim maxrow As Integer = 0
        con.Open()
        ds.Clear()
        squery = "SELECT * FROM Userfle order by UserID"
        aa = New OleDb.OleDbDataAdapter(squery, con)
        aa.Fill(ds, "LVW")
        con.Close()
        maxrow = ds.Tables("LVW").Rows.Count
        Try
            ListView1.Items.Clear()
            Dim intCount As Integer = 0
            While Not intCount = maxrow
                ListView1.Items.Add(ds.Tables("LVW").Rows(intCount).Item(0))
                ListView1.Items(CInt(intCount)).SubItems.Add(ds.Tables("LVW").Rows(intCount).Item(1))
                ListView1.Items(CInt(intCount)).SubItems.Add(ds.Tables("LVW").Rows(intCount).Item(2))
                ListView1.Items(CInt(intCount)).SubItems.Add(ds.Tables("LVW").Rows(intCount).Item(3))
                ListView1.Items(CInt(intCount)).SubItems.Add(ds.Tables("LVW").Rows(intCount).Item(4))
                ListView1.Items(CInt(intCount)).SubItems.Add(ds.Tables("LVW").Rows(intCount).Item(5))
                ListView1.Items(CInt(intCount)).SubItems.Add(ds.Tables("LVW").Rows(intCount).Item(6))
                ListView1.Items(CInt(intCount)).SubItems.Add(ds.Tables("LVW").Rows(intCount).Item(7))
                ListView1.Items(CInt(intCount)).SubItems.Add(ds.Tables("LVW").Rows(intCount).Item(8))
                ListView1.Items(CInt(intCount)).SubItems.Add(ds.Tables("LVW").Rows(intCount).Item(9))
                intCount = intCount + 1

            End While
        Catch ex As Exception

        End Try

    End Sub

End Class
