<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.TxtUserID = New System.Windows.Forms.TextBox
        Me.BtnCancel = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.BtnOK = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.TxtPass = New System.Windows.Forms.TextBox
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.TxtCl = New System.Windows.Forms.TextBox
        Me.TxtFl = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.TxtSeat = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.CmbFlag = New System.Windows.Forms.ComboBox
        Me.TxtUsrPass = New System.Windows.Forms.TextBox
        Me.TxtMid = New System.Windows.Forms.TextBox
        Me.TxtFirst = New System.Windows.Forms.TextBox
        Me.TxtLast = New System.Windows.Forms.TextBox
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.BtnUsrCancel = New System.Windows.Forms.Button
        Me.BtnUsrSave = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.LblRem = New System.Windows.Forms.Label
        Me.BtnUsrSearch = New System.Windows.Forms.Button
        Me.TxtUsrID = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.STsys = New System.Windows.Forms.ToolStripMenuItem
        Me.LogIn = New System.Windows.Forms.ToolStripMenuItem
        Me.LogOut = New System.Windows.Forms.ToolStripMenuItem
        Me.Quit = New System.Windows.Forms.ToolStripMenuItem
        Me.STua = New System.Windows.Forms.ToolStripMenuItem
        Me.NewUserToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.EditUser = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteUser = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewUser = New System.Windows.Forms.ToolStripMenuItem
        Me.Rprt = New System.Windows.Forms.ToolStripMenuItem
        Me.ListView = New System.Windows.Forms.ToolStripMenuItem
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.LblRem2 = New System.Windows.Forms.Label
        Me.BtnShow = New System.Windows.Forms.Button
        Me.ListView1 = New System.Windows.Forms.ListView
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader4 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader5 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader6 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader7 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader8 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader9 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader10 = New System.Windows.Forms.ColumnHeader
        Me.LabelTitle = New System.Windows.Forms.Label
        Me.PictureBox3 = New System.Windows.Forms.PictureBox
        Me.PictureBox4 = New System.Windows.Forms.PictureBox
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(-51, -32)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(829, 722)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 10
        Me.PictureBox2.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.TxtUserID)
        Me.Panel1.Controls.Add(Me.BtnCancel)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.BtnOK)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.TxtPass)
        Me.Panel1.Location = New System.Drawing.Point(698, 312)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(368, 168)
        Me.Panel1.TabIndex = 11
        Me.Panel1.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.ErrorImage = Nothing
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(21, 19)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(116, 126)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'TxtUserID
        '
        Me.TxtUserID.Location = New System.Drawing.Point(224, 54)
        Me.TxtUserID.MaxLength = 10
        Me.TxtUserID.Name = "TxtUserID"
        Me.TxtUserID.Size = New System.Drawing.Size(119, 20)
        Me.TxtUserID.TabIndex = 2
        '
        'BtnCancel
        '
        Me.BtnCancel.Location = New System.Drawing.Point(267, 106)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.Size = New System.Drawing.Size(60, 23)
        Me.BtnCancel.TabIndex = 5
        Me.BtnCancel.Text = "CANCEL"
        Me.BtnCancel.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(160, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "User ID"
        '
        'BtnOK
        '
        Me.BtnOK.Location = New System.Drawing.Point(201, 106)
        Me.BtnOK.Name = "BtnOK"
        Me.BtnOK.Size = New System.Drawing.Size(60, 23)
        Me.BtnOK.TabIndex = 4
        Me.BtnOK.Text = "OK"
        Me.BtnOK.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(143, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Password"
        '
        'TxtPass
        '
        Me.TxtPass.Location = New System.Drawing.Point(224, 80)
        Me.TxtPass.MaxLength = 10
        Me.TxtPass.Name = "TxtPass"
        Me.TxtPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TxtPass.Size = New System.Drawing.Size(119, 20)
        Me.TxtPass.TabIndex = 3
        '
        'Panel3
        '
        Me.Panel3.BackgroundImage = CType(resources.GetObject("Panel3.BackgroundImage"), System.Drawing.Image)
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.PictureBox3)
        Me.Panel3.Controls.Add(Me.TxtCl)
        Me.Panel3.Controls.Add(Me.TxtFl)
        Me.Panel3.Controls.Add(Me.Label12)
        Me.Panel3.Controls.Add(Me.TxtSeat)
        Me.Panel3.Controls.Add(Me.Label11)
        Me.Panel3.Controls.Add(Me.Label10)
        Me.Panel3.Controls.Add(Me.DateTimePicker1)
        Me.Panel3.Controls.Add(Me.CmbFlag)
        Me.Panel3.Controls.Add(Me.TxtUsrPass)
        Me.Panel3.Controls.Add(Me.TxtMid)
        Me.Panel3.Controls.Add(Me.TxtFirst)
        Me.Panel3.Controls.Add(Me.TxtLast)
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Location = New System.Drawing.Point(116, 124)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(576, 248)
        Me.Panel3.TabIndex = 12
        Me.Panel3.Visible = False
        '
        'TxtCl
        '
        Me.TxtCl.Location = New System.Drawing.Point(387, 79)
        Me.TxtCl.MaxLength = 10
        Me.TxtCl.Name = "TxtCl"
        Me.TxtCl.Size = New System.Drawing.Size(100, 20)
        Me.TxtCl.TabIndex = 23
        '
        'TxtFl
        '
        Me.TxtFl.Location = New System.Drawing.Point(188, 107)
        Me.TxtFl.MaxLength = 30
        Me.TxtFl.Name = "TxtFl"
        Me.TxtFl.Size = New System.Drawing.Size(100, 20)
        Me.TxtFl.TabIndex = 22
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.SeaShell
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(102, 110)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(76, 15)
        Me.Label12.TabIndex = 21
        Me.Label12.Text = "Flight Name"
        '
        'TxtSeat
        '
        Me.TxtSeat.Location = New System.Drawing.Point(387, 107)
        Me.TxtSeat.MaxLength = 10
        Me.TxtSeat.Name = "TxtSeat"
        Me.TxtSeat.Size = New System.Drawing.Size(38, 20)
        Me.TxtSeat.TabIndex = 19
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.SeaShell
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(314, 110)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(35, 15)
        Me.Label11.TabIndex = 18
        Me.Label11.Text = "Seat"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.SeaShell
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(314, 82)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(39, 15)
        Me.Label10.TabIndex = 17
        Me.Label10.Text = "Class"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(387, 29)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(100, 20)
        Me.DateTimePicker1.TabIndex = 16
        '
        'CmbFlag
        '
        Me.CmbFlag.FormattingEnabled = True
        Me.CmbFlag.Items.AddRange(New Object() {"M", "F"})
        Me.CmbFlag.Location = New System.Drawing.Point(387, 53)
        Me.CmbFlag.Name = "CmbFlag"
        Me.CmbFlag.Size = New System.Drawing.Size(48, 21)
        Me.CmbFlag.TabIndex = 15
        '
        'TxtUsrPass
        '
        Me.TxtUsrPass.Location = New System.Drawing.Point(290, 143)
        Me.TxtUsrPass.MaxLength = 10
        Me.TxtUsrPass.Name = "TxtUsrPass"
        Me.TxtUsrPass.Size = New System.Drawing.Size(100, 20)
        Me.TxtUsrPass.TabIndex = 13
        '
        'TxtMid
        '
        Me.TxtMid.Location = New System.Drawing.Point(188, 79)
        Me.TxtMid.MaxLength = 31
        Me.TxtMid.Name = "TxtMid"
        Me.TxtMid.Size = New System.Drawing.Size(100, 20)
        Me.TxtMid.TabIndex = 12
        '
        'TxtFirst
        '
        Me.TxtFirst.Location = New System.Drawing.Point(188, 53)
        Me.TxtFirst.MaxLength = 31
        Me.TxtFirst.Name = "TxtFirst"
        Me.TxtFirst.Size = New System.Drawing.Size(100, 20)
        Me.TxtFirst.TabIndex = 11
        '
        'TxtLast
        '
        Me.TxtLast.Location = New System.Drawing.Point(188, 25)
        Me.TxtLast.MaxLength = 31
        Me.TxtLast.Name = "TxtLast"
        Me.TxtLast.Size = New System.Drawing.Size(100, 20)
        Me.TxtLast.TabIndex = 10
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.BtnUsrCancel)
        Me.Panel4.Controls.Add(Me.BtnUsrSave)
        Me.Panel4.Location = New System.Drawing.Point(195, 179)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(192, 46)
        Me.Panel4.TabIndex = 9
        '
        'BtnUsrCancel
        '
        Me.BtnUsrCancel.Location = New System.Drawing.Point(97, 10)
        Me.BtnUsrCancel.Name = "BtnUsrCancel"
        Me.BtnUsrCancel.Size = New System.Drawing.Size(75, 23)
        Me.BtnUsrCancel.TabIndex = 4
        Me.BtnUsrCancel.Text = "Cancel"
        Me.BtnUsrCancel.UseVisualStyleBackColor = True
        '
        'BtnUsrSave
        '
        Me.BtnUsrSave.Location = New System.Drawing.Point(16, 10)
        Me.BtnUsrSave.Name = "BtnUsrSave"
        Me.BtnUsrSave.Size = New System.Drawing.Size(75, 23)
        Me.BtnUsrSave.TabIndex = 3
        Me.BtnUsrSave.Text = "Save"
        Me.BtnUsrSave.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.SeaShell
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(314, 55)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(50, 15)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "Gender"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.SeaShell
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(314, 29)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 15)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Flight Date"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.SeaShell
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(217, 146)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 15)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Password"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.SeaShell
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(116, 82)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 15)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Mid Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.SeaShell
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(115, 56)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 15)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "First Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.SeaShell
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(115, 28)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 15)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Last Name"
        '
        'Panel2
        '
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.LblRem)
        Me.Panel2.Controls.Add(Me.BtnUsrSearch)
        Me.Panel2.Controls.Add(Me.TxtUsrID)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Location = New System.Drawing.Point(22, 382)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(520, 42)
        Me.Panel2.TabIndex = 13
        Me.Panel2.Visible = False
        '
        'LblRem
        '
        Me.LblRem.AutoSize = True
        Me.LblRem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblRem.Font = New System.Drawing.Font("Agency FB", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRem.Location = New System.Drawing.Point(318, 8)
        Me.LblRem.Name = "LblRem"
        Me.LblRem.Size = New System.Drawing.Size(53, 26)
        Me.LblRem.TabIndex = 9
        Me.LblRem.Text = "Label10"
        '
        'BtnUsrSearch
        '
        Me.BtnUsrSearch.Location = New System.Drawing.Point(228, 8)
        Me.BtnUsrSearch.Name = "BtnUsrSearch"
        Me.BtnUsrSearch.Size = New System.Drawing.Size(75, 23)
        Me.BtnUsrSearch.TabIndex = 2
        Me.BtnUsrSearch.Text = "Search"
        Me.BtnUsrSearch.UseVisualStyleBackColor = True
        '
        'TxtUsrID
        '
        Me.TxtUsrID.Location = New System.Drawing.Point(86, 10)
        Me.TxtUsrID.MaxLength = 10
        Me.TxtUsrID.Name = "TxtUsrID"
        Me.TxtUsrID.Size = New System.Drawing.Size(112, 20)
        Me.TxtUsrID.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(26, 13)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 15)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "User ID"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.STsys, Me.STua})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(705, 24)
        Me.MenuStrip1.TabIndex = 14
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'STsys
        '
        Me.STsys.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LogIn, Me.LogOut, Me.Quit})
        Me.STsys.Name = "STsys"
        Me.STsys.Size = New System.Drawing.Size(57, 20)
        Me.STsys.Text = "System"
        '
        'LogIn
        '
        Me.LogIn.Name = "LogIn"
        Me.LogIn.Size = New System.Drawing.Size(117, 22)
        Me.LogIn.Text = "Log In"
        '
        'LogOut
        '
        Me.LogOut.Enabled = False
        Me.LogOut.Name = "LogOut"
        Me.LogOut.Size = New System.Drawing.Size(117, 22)
        Me.LogOut.Text = "Log Out"
        '
        'Quit
        '
        Me.Quit.Name = "Quit"
        Me.Quit.Size = New System.Drawing.Size(117, 22)
        Me.Quit.Text = "Quit"
        '
        'STua
        '
        Me.STua.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewUserToolStripMenuItem1, Me.EditUser, Me.DeleteUser, Me.ViewUser, Me.Rprt, Me.ListView})
        Me.STua.Enabled = False
        Me.STua.Name = "STua"
        Me.STua.Size = New System.Drawing.Size(85, 20)
        Me.STua.Text = "Reservations"
        '
        'NewUserToolStripMenuItem1
        '
        Me.NewUserToolStripMenuItem1.Name = "NewUserToolStripMenuItem1"
        Me.NewUserToolStripMenuItem1.Size = New System.Drawing.Size(171, 22)
        Me.NewUserToolStripMenuItem1.Text = "New Reservation"
        '
        'EditUser
        '
        Me.EditUser.Name = "EditUser"
        Me.EditUser.Size = New System.Drawing.Size(171, 22)
        Me.EditUser.Text = "Edit Reservation"
        '
        'DeleteUser
        '
        Me.DeleteUser.Name = "DeleteUser"
        Me.DeleteUser.Size = New System.Drawing.Size(171, 22)
        Me.DeleteUser.Text = "Delete Reservation"
        '
        'ViewUser
        '
        Me.ViewUser.Name = "ViewUser"
        Me.ViewUser.Size = New System.Drawing.Size(171, 22)
        Me.ViewUser.Text = "View Reservation"
        '
        'Rprt
        '
        Me.Rprt.Name = "Rprt"
        Me.Rprt.Size = New System.Drawing.Size(171, 22)
        Me.Rprt.Text = "Print Reservations"
        '
        'ListView
        '
        Me.ListView.Name = "ListView"
        Me.ListView.Size = New System.Drawing.Size(171, 22)
        Me.ListView.Text = "View Flights"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel5.BackgroundImage = CType(resources.GetObject("Panel5.BackgroundImage"), System.Drawing.Image)
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.PictureBox4)
        Me.Panel5.Controls.Add(Me.LblRem2)
        Me.Panel5.Controls.Add(Me.BtnShow)
        Me.Panel5.Controls.Add(Me.ListView1)
        Me.Panel5.Location = New System.Drawing.Point(595, 387)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(681, 329)
        Me.Panel5.TabIndex = 15
        Me.Panel5.Visible = False
        '
        'LblRem2
        '
        Me.LblRem2.AutoSize = True
        Me.LblRem2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblRem2.Font = New System.Drawing.Font("Agency FB", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRem2.Location = New System.Drawing.Point(485, 13)
        Me.LblRem2.Name = "LblRem2"
        Me.LblRem2.Size = New System.Drawing.Size(53, 26)
        Me.LblRem2.TabIndex = 10
        Me.LblRem2.Text = "Label10"
        '
        'BtnShow
        '
        Me.BtnShow.Location = New System.Drawing.Point(54, 13)
        Me.BtnShow.Name = "BtnShow"
        Me.BtnShow.Size = New System.Drawing.Size(75, 23)
        Me.BtnShow.TabIndex = 4
        Me.BtnShow.Text = "Show"
        Me.BtnShow.UseVisualStyleBackColor = True
        '
        'ListView1
        '
        Me.ListView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7, Me.ColumnHeader8, Me.ColumnHeader9, Me.ColumnHeader10})
        Me.ListView1.Location = New System.Drawing.Point(4, 50)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(672, 275)
        Me.ListView1.TabIndex = 3
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "User ID"
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Password"
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Last Name"
        Me.ColumnHeader3.Width = 73
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "First Name"
        Me.ColumnHeader4.Width = 72
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Mid Name"
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "Gender"
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "Flight Name"
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "Class"
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "Flight Date"
        '
        'ColumnHeader10
        '
        Me.ColumnHeader10.Text = "Seat"
        '
        'LabelTitle
        '
        Me.LabelTitle.AutoSize = True
        Me.LabelTitle.BackColor = System.Drawing.Color.Gainsboro
        Me.LabelTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabelTitle.Font = New System.Drawing.Font("Agency FB", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTitle.Location = New System.Drawing.Point(12, 37)
        Me.LabelTitle.Name = "LabelTitle"
        Me.LabelTitle.Size = New System.Drawing.Size(485, 61)
        Me.LabelTitle.TabIndex = 16
        Me.LabelTitle.Text = "ASIIMOV AIRLINE RESERVATION"
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(15, 25)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(80, 79)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 24
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(17, 10)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(31, 28)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 11
        Me.PictureBox4.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(705, 405)
        Me.Controls.Add(Me.LabelTitle)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Name = "Form1"
        Me.Text = "Asiimov Airline Reservation Service"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TxtUserID As System.Windows.Forms.TextBox
    Friend WithEvents BtnCancel As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BtnOK As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtPass As System.Windows.Forms.TextBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents TxtFl As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TxtSeat As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents CmbFlag As System.Windows.Forms.ComboBox
    Friend WithEvents TxtUsrPass As System.Windows.Forms.TextBox
    Friend WithEvents TxtMid As System.Windows.Forms.TextBox
    Friend WithEvents TxtFirst As System.Windows.Forms.TextBox
    Friend WithEvents TxtLast As System.Windows.Forms.TextBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents BtnUsrCancel As System.Windows.Forms.Button
    Friend WithEvents BtnUsrSave As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents LblRem As System.Windows.Forms.Label
    Friend WithEvents BtnUsrSearch As System.Windows.Forms.Button
    Friend WithEvents TxtUsrID As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents STsys As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogIn As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Quit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents STua As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewUserToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditUser As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteUser As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewUser As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Rprt As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListView As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TxtCl As System.Windows.Forms.TextBox
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents BtnShow As System.Windows.Forms.Button
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents LblRem2 As System.Windows.Forms.Label
    Friend WithEvents LabelTitle As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox

End Class
