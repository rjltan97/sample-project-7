Module Module1
    Public con As New OleDb.OleDbConnection
End Module
