Imports CrystalDecisions.CrystalReports.Engine
Public Class Form2

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cryrpt As New ReportDocument
        cryrpt.Load("D:\RLT_FINALS\APP\WindowsApplication1\WindowsApplication1\CrystalReport1.rpt")
        CrystalReportViewer1().ReportSource = cryrpt
        CrystalReportViewer1.Refresh()
    End Sub

    Private Sub CrystalReportViewer1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrystalReportViewer1.Load

    End Sub
End Class