/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nameapplet;

import javax.swing.JApplet;
import java.awt.*;
public class NameApplet2 extends JApplet {
    
    Font header = new Font("SansSerif", Font.BOLD, 24);
    String text, text2;
    int delayLimit;
		
    @Override
    public void init() {
	text = "Robin Tan";
        text2 = "Haruhiko";
	delayLimit = 50000000;
    }
	
    @Override
    public void paint(Graphics g) {
        int y2= 200;
	g.setFont(header);
	for(int y = 0; y < 60; y++) {
            //user-defined delay function
            for(int delay = 0; delay < delayLimit; delay++);
			
            g.setColor(new Color(255, 255, 255));	//white
            g.fillRect(0, y-20, 500, 100);
            g.setColor(new Color(0, 0, 0));	//black
            g.drawString(text, 0, y+20);
	     
            //user-defined delay function

            g.setColor(new Color(255, 255, 255));	//white
            g.fillRect(0, y2-20, 500, 100);
            g.setColor(new Color(0, 0, 0));	//black
            g.drawString(text2, 0, y2--);
	}               
    }   
}
