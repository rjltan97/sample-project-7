
package nameapplet;

import java.awt.*;
import javax.swing.JApplet;

public class NameApplet extends JApplet {
    
    Font sansBold = new Font("Helvetica", Font.BOLD, 25);
    String text;
    int delayLimit;
    int shade;
	
    public void init() {
	text = "Robin Tan";
	delayLimit = 50000000;
    }
	
  
    public void paint(Graphics g) {
        
        for (int x=0; x<=20; x++){    
        for(shade = 0; shade < 256; shade++) {
            g.setFont(sansBold);
            g.setColor(new Color(shade, shade, shade));	
            g.drawString(text, 0, 100);
            //user-defined delay function
            for(int delay = 0; delay < 500000; delay++);

        }	
            for(shade = 0; shade < 256; shade++) {
            g.setFont(sansBold);
            g.setColor(Color.RED);	
            g.drawString(text, 0, 100);
            //user-defined delay function
            for(int delay = 0; delay < 500000; delay++);

        }
    }
    }
}
