
package billingapp;
import javax.swing.*;

public class BillingAppUI extends javax.swing.JFrame {

    ImageIcon image[]=
    {
        new ImageIcon("nutella.jpg"),
        new ImageIcon("choco.jpg"),
        new ImageIcon("cotoffee.jpg"),
        new ImageIcon("coffee.jpg"),
        new ImageIcon("cnc.jpg"),
        new ImageIcon("double.jpg"),
        new ImageIcon("haze1.jpg"),
        new ImageIcon("hazelnut.jpg"),
        new ImageIcon("heath.jpg"),
        new ImageIcon("straw.jpg"),
        new ImageIcon("rocky.jpg"),
        new ImageIcon("almond.jpg"),
        new ImageIcon("bub.jpg"),
        new ImageIcon("vanilla.jpg"),
        new ImageIcon("magraham.jpg"),
        new ImageIcon("reg1.jpg"),
        new ImageIcon("spe2.jpg"),
        new ImageIcon("pre3.jpg"),
    };
    
    String flavorType= null;
    String flavor = null;
    int noofscoops = 0, addontot=0;
    String addon1= null, addon2= null, addon3= null, kname = null, sname = null;
    double partialBill=0.0, totalBill = 0.0;
    double addonp=0.0,  kprice=0.0;
    
    public BillingAppUI() {
        initComponents();
        HiddenButton.setVisible(false);
        Reg.setIcon(image[15]);
        Spe.setIcon(image[16]);
        Pre.setIcon(image[17]);
        RegList.setEnabled(false);
        SpeList.setEnabled(false);
        PreList.setEnabled(false);
        
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        Reg = new javax.swing.JButton();
        Spe = new javax.swing.JButton();
        Pre = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        RegList = new javax.swing.JList();
        jScrollPane2 = new javax.swing.JScrollPane();
        SpeList = new javax.swing.JList();
        jScrollPane3 = new javax.swing.JScrollPane();
        PreList = new javax.swing.JList();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        Order = new javax.swing.JButton();
        Cancel = new javax.swing.JButton();
        Scoop1 = new javax.swing.JRadioButton();
        Scoop2 = new javax.swing.JRadioButton();
        Scoop3 = new javax.swing.JRadioButton();
        ChocoDipCheck = new javax.swing.JCheckBox();
        SprinklesCheck = new javax.swing.JCheckBox();
        MallowsCheck = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        HiddenButton = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        NewOrder = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem6 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Myriad Colors Ice Cream");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(255, 140, 0));

        Reg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegActionPerformed(evt);
            }
        });

        Spe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SpeActionPerformed(evt);
            }
        });

        Pre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PreActionPerformed(evt);
            }
        });

        RegList.setBackground(new java.awt.Color(225, 222, 222));
        RegList.setFont(new java.awt.Font("Tahoma", 1, 11));
        RegList.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Chocolate", "Vanilla", "Coffee", "Hazelnut", "Strawberry" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        RegList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                RegListValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(RegList);

        SpeList.setBackground(new java.awt.Color(225, 222, 222));
        SpeList.setFont(new java.awt.Font("Tahoma", 1, 11));
        SpeList.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Rocky Road", "Cookies n Cream", "Double Dutch", "Bubblegum", "Coffee Toffee" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        SpeList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                SpeListValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(SpeList);

        PreList.setBackground(new java.awt.Color(225, 222, 222));
        PreList.setFont(new java.awt.Font("Tahoma", 1, 11));
        PreList.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Hershey's Heath", "Hazelnut Brownie", "Choco Almond Fudge", "Nutella Ice Cream", "Mango Graham" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        PreList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                PreListValueChanged(evt);
            }
        });
        jScrollPane3.setViewportView(PreList);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel4.setText("REGULAR");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel5.setText("SPECIAL");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel6.setText("PREMIUM");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                    .addComponent(Reg, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2)
                    .addComponent(Spe, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3)
                    .addComponent(Pre, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 145, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(130, 130, 130)
                .addComponent(jLabel6)
                .addGap(84, 84, 84))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Reg, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Spe, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pre, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, 0, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, 0, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(jLabel5))
                    .addComponent(jLabel4))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(54, 54, 54));

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));

        Order.setText("PLACE ORDER");
        Order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OrderActionPerformed(evt);
            }
        });

        Cancel.setText("CANCEL");
        Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Order, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Cancel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(Order)
                .addGap(18, 18, 18)
                .addComponent(Cancel)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        Scoop1.setBackground(new java.awt.Color(255, 140, 51));
        buttonGroup1.add(Scoop1);
        Scoop1.setText("Single Scoop");
        Scoop1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                Scoop1ItemStateChanged(evt);
            }
        });

        Scoop2.setBackground(new java.awt.Color(255, 140, 51));
        buttonGroup1.add(Scoop2);
        Scoop2.setText("Double Scoop");
        Scoop2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                Scoop2ItemStateChanged(evt);
            }
        });

        Scoop3.setBackground(new java.awt.Color(255, 140, 51));
        buttonGroup1.add(Scoop3);
        Scoop3.setText("Triple Scoop");
        Scoop3.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                Scoop3ItemStateChanged(evt);
            }
        });

        ChocoDipCheck.setBackground(new java.awt.Color(255, 140, 51));
        ChocoDipCheck.setText("Chocolate Dip");
        ChocoDipCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChocoDipCheckActionPerformed(evt);
            }
        });

        SprinklesCheck.setBackground(new java.awt.Color(255, 140, 51));
        SprinklesCheck.setText("Sprinkles");
        SprinklesCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SprinklesCheckActionPerformed(evt);
            }
        });

        MallowsCheck.setBackground(new java.awt.Color(255, 140, 51));
        MallowsCheck.setText("Mallows");
        MallowsCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MallowsCheckActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 140, 51));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel1.setText("NUMBER OF SCOOPS");
        jLabel1.setOpaque(true);

        jLabel2.setBackground(new java.awt.Color(255, 140, 51));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel2.setText("ADD-ONS");
        jLabel2.setOpaque(true);

        buttonGroup1.add(HiddenButton);
        HiddenButton.setText("Hidden");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(109, 109, 109))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(Scoop1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Scoop2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Scoop3, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ChocoDipCheck)
                            .addComponent(SprinklesCheck)
                            .addComponent(MallowsCheck)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 113, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(HiddenButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(ChocoDipCheck)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(SprinklesCheck)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(MallowsCheck))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(Scoop1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Scoop2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Scoop3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(HiddenButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setBackground(new java.awt.Color(255, 140, 0));
        jLabel3.setFont(new java.awt.Font("Verdana", 1, 12));
        jLabel3.setText("Myriad Colors Ice Cream Parlor");
        jLabel3.setOpaque(true);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 579, Short.MAX_VALUE)
                        .addGap(20, 20, 20))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(20, 20, 20))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jMenu1.setText("File");

        NewOrder.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        NewOrder.setText("New Order");
        NewOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NewOrderActionPerformed(evt);
            }
        });
        jMenu1.add(NewOrder);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText("Save Order");
        jMenu1.add(jMenuItem2);

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.ALT_MASK));
        jMenuItem3.setText("Quit");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("View");

        jMenuItem4.setText("View Products");
        jMenu2.add(jMenuItem4);

        jMenuItem5.setText("View Sales");
        jMenu2.add(jMenuItem5);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("About");

        jMenuItem6.setText("About Myriad Colors");
        jMenu3.add(jMenuItem6);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    private void RegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegActionPerformed
        // TODO add your handling code here:
        RegList.setEnabled(true);
        SpeList.setEnabled(false);
        PreList.setEnabled(false);
        Spe.setIcon(image[16]);
        Pre.setIcon(image[17]);
        kprice=150.0;
        kname="Regular";
    }//GEN-LAST:event_RegActionPerformed

    private void SpeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SpeActionPerformed
        // TODO add your handling code here:
        RegList.setEnabled(false);
        SpeList.setEnabled(true);
        PreList.setEnabled(false);
        Reg.setIcon(image[15]);
        Pre.setIcon(image[17]);
        kprice=350.0;
        kname="Special";
    }//GEN-LAST:event_SpeActionPerformed

    private void PreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PreActionPerformed
        // TODO add your handling code here:
        
        RegList.setEnabled(false);
        SpeList.setEnabled(false);
        PreList.setEnabled(true);
        Reg.setIcon(image[15]);
        Spe.setIcon(image[16]);
        kprice=500.0;
        kname="Premium";
    }//GEN-LAST:event_PreActionPerformed

    private void CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelActionPerformed
        // TODO add your handling code here:
        RegList.clearSelection();
        SpeList.clearSelection();
        PreList.clearSelection();
        Reg.setIcon(image[15]);
        Spe.setIcon(image[16]);
        Pre.setIcon(image[17]);
        HiddenButton.setSelected(true);
        ChocoDipCheck.setSelected(false);
        MallowsCheck.setSelected(false);
        SprinklesCheck.setSelected(false);
        partialBill=0.0;
        noofscoops=0;
        addonp=0.0;
        kprice=0.0;
        RegList.setEnabled(false);
        SpeList.setEnabled(false);
        PreList.setEnabled(false);
        addontot=0;
        kname = null;
        flavorType = null;
        addon1 = null;
        addon2 = null;
        addon3 = null;
        sname = null;
    }//GEN-LAST:event_CancelActionPerformed

    private void Scoop1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_Scoop1ItemStateChanged
        // TODO add your handling code here:
        noofscoops=1;
        sname = "Single Scoop";
    }//GEN-LAST:event_Scoop1ItemStateChanged

    private void Scoop2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_Scoop2ItemStateChanged
        // TODO add your handling code here:
        noofscoops=2;
        sname = "Double Scoop";
    }//GEN-LAST:event_Scoop2ItemStateChanged

    private void Scoop3ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_Scoop3ItemStateChanged
        // TODO add your handling code here:
        noofscoops=3;
        sname = "Triple Scoop";
    }//GEN-LAST:event_Scoop3ItemStateChanged

    private void RegListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_RegListValueChanged
        // TODO add your handling code here:
         int selectedFlavorIndex = RegList.getSelectedIndex();
        
        if (selectedFlavorIndex == 0){
            flavor = RegList.getSelectedValue().toString();
            Reg.setIcon(image[1]);
            flavorType ="Chocolate";
        } else if (selectedFlavorIndex == 1){
            flavor = RegList.getSelectedValue().toString();
            Reg.setIcon(image[13]);
            flavorType ="Vanilla";
        } else if (selectedFlavorIndex == 2){
            flavor = RegList.getSelectedValue().toString();
            Reg.setIcon(image[3]);
            flavorType ="Coffee";
        } else if (selectedFlavorIndex == 3){
            flavor = RegList.getSelectedValue().toString();
            Reg.setIcon(image[6]);
            flavorType ="Hazelnut";
        } else if (selectedFlavorIndex == 4){
            flavor = RegList.getSelectedValue().toString();
            Reg.setIcon(image[9]);
            flavorType ="Strawberry";
        }
    }//GEN-LAST:event_RegListValueChanged

    private void SpeListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_SpeListValueChanged
        // TODO add your handling code here:
        int selectedFlavorIndex = SpeList.getSelectedIndex();
        
        if (selectedFlavorIndex == 0){
            flavor = SpeList.getSelectedValue().toString();
            Spe.setIcon(image[10]);
            flavorType ="Rocky Road";
        } else if (selectedFlavorIndex == 1){
            flavor = SpeList.getSelectedValue().toString();
            Spe.setIcon(image[4]);
            flavorType ="Cookies and Cream";
        } else if (selectedFlavorIndex == 2){
            flavor = SpeList.getSelectedValue().toString();
            Spe.setIcon(image[5]);
            flavorType ="Double Dutch";
        } else if (selectedFlavorIndex == 3){
            flavor = SpeList.getSelectedValue().toString();
            Spe.setIcon(image[12]);
            flavorType ="Bubblegum";
        } else if (selectedFlavorIndex == 4){
            flavor = SpeList.getSelectedValue().toString();
            Spe.setIcon(image[2]);
            flavorType ="Coffee Toffee";
        }
    }//GEN-LAST:event_SpeListValueChanged

    private void PreListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_PreListValueChanged
        // TODO add your handling code here:
         int selectedFlavorIndex = PreList.getSelectedIndex();
        
        if (selectedFlavorIndex == 0){
            flavor = PreList.getSelectedValue().toString();
            Pre.setIcon(image[8]);
            flavorType ="Hershey's Heath";
        } else if (selectedFlavorIndex == 1){
            flavor = PreList.getSelectedValue().toString();
            Pre.setIcon(image[7]);
            flavorType ="Hazelnut Brownie";
        } else if (selectedFlavorIndex == 2){
            flavor = PreList.getSelectedValue().toString();
            Pre.setIcon(image[11]);
            flavorType ="Choco Almond Fudge";
        } else if (selectedFlavorIndex == 3){
            flavor = PreList.getSelectedValue().toString();
            Pre.setIcon(image[0]);
            flavorType ="Nutella Ice Cream";
        } else if (selectedFlavorIndex == 4){
            flavor = PreList.getSelectedValue().toString();
            Pre.setIcon(image[14]);
            flavorType ="Mango Graham";
        }
    }//GEN-LAST:event_PreListValueChanged

    private void ChocoDipCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChocoDipCheckActionPerformed
        // TODO add your handling code here:
        addonp+=10.0;
        addontot+=1;
        addon1 = "Choco Dip";
    }//GEN-LAST:event_ChocoDipCheckActionPerformed

    private void SprinklesCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SprinklesCheckActionPerformed
        // TODO add your handling code here:
        addonp+=10.0;
        addontot+=1;
        addon2 = "Sprinles";
    }//GEN-LAST:event_SprinklesCheckActionPerformed

    private void MallowsCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MallowsCheckActionPerformed
        // TODO add your handling code here:
        addonp+=10.0;
        addontot+=1;
        addon3 = "Mallows";
    }//GEN-LAST:event_MallowsCheckActionPerformed

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
        // TODO add your handling code here:
        partialBill=kprice*noofscoops+addonp;
        JOptionPane.showMessageDialog(null, "Your Partial Bill is: " + partialBill +"\nType of Ice Cream: " + kname + "\nFlavor: " + flavorType + "\nScoop: " + sname + "\nNumber of Add-ons: " + addontot +"\nAdd-ons: "+"\n"+ addon1+"\n"+addon2+"\n"+addon3, "Information", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_OrderActionPerformed

    private void NewOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NewOrderActionPerformed
        // TODO add your handling code here:
        RegList.clearSelection();
        SpeList.clearSelection();
        PreList.clearSelection();
        Reg.setIcon(image[15]);
        Spe.setIcon(image[16]);
        Pre.setIcon(image[17]);
        HiddenButton.setSelected(true);
        ChocoDipCheck.setSelected(false);
        MallowsCheck.setSelected(false);
        SprinklesCheck.setSelected(false);
        partialBill=0.0;
        noofscoops=0;
        addonp=0.0;
        kprice=0.0;
        RegList.setEnabled(false);
        SpeList.setEnabled(false);
        PreList.setEnabled(false);
        addontot=0;
        kname = null;
        flavorType = null;
        addon1 = null;
        addon2 = null;
        addon3 = null;
        sname = null;
    }//GEN-LAST:event_NewOrderActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jMenuItem3ActionPerformed


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new BillingAppUI().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancel;
    private javax.swing.JCheckBox ChocoDipCheck;
    private javax.swing.JRadioButton HiddenButton;
    private javax.swing.JCheckBox MallowsCheck;
    private javax.swing.JMenuItem NewOrder;
    private javax.swing.JButton Order;
    private javax.swing.JButton Pre;
    private javax.swing.JList PreList;
    private javax.swing.JButton Reg;
    private javax.swing.JList RegList;
    private javax.swing.JRadioButton Scoop1;
    private javax.swing.JRadioButton Scoop2;
    private javax.swing.JRadioButton Scoop3;
    private javax.swing.JButton Spe;
    private javax.swing.JList SpeList;
    private javax.swing.JCheckBox SprinklesCheck;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables
}
