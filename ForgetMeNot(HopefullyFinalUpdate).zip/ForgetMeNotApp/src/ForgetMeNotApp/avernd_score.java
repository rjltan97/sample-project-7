
package ForgetMeNotApp;

public class avernd_score {
    
    static int fnl_score = 0;     
    
    public static void scoreaccum(int score)
    {
        fnl_score += score;
    } 
    
    public static int disp_score()
    {
        return fnl_score;
    }
}
